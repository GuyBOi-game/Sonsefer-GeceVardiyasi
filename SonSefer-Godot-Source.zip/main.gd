extends Control

const INK := Color("#071426")
const DEEP := Color("#0b1c31")
const PANEL := Color("#10253a")
const PANEL_LIGHT := Color("#17334a")
const GOLD := Color("#f2c879")
const CREAM := Color("#f1eadc")
const MUTED := Color("#9eafbf")
const TEAL := Color("#83c7bd")
const RED := Color("#e58d7d")
const CaseBank = preload("res://case_bank.gd")
const SteamBridgeScript = preload("res://steam_bridge.gd")
const TICKET_INSPECT_ID := -1
const ACHIEVEMENT_DEFINITIONS := [
	{"id": "FIRST_DUTY", "title": "İlk Düdük", "description": "İlk yolcu dosyanı tamamla."},
	{"id": "CHAPTER_ONE", "title": "Vardiya Şefi", "description": "İlk bölümü tamamla."},
	{"id": "SHARP_EYE", "title": "Keskin Göz", "description": "On kanıt panosu çıkarımını doğru çöz."},
	{"id": "NIGHT_WATCH", "title": "Nöbet Defteri", "description": "Gizli defterin on sayfasını da bul."},
	{"id": "STEADY_HAND", "title": "Soğukkanlı", "description": "Arka arkaya on doğru karar ver."},
	{"id": "ALL_ENDINGS", "title": "Yedi Sabah", "description": "Yedi farklı finali gör."},
	{"id": "LAST_PASSENGER", "title": "Son Yolcu", "description": "Yüz dosyanın hepsini tamamla."}
]
const CHAPTER_TITLES := ["SON VAPUR", "ISLAK MEKTUP", "SAAT FARKI", "EMANET", "BOŞ KOLTUK", "SİNYAL", "KAYIP DEFTER", "PERDE ARKASI", "İSKELEDE YANKI", "GÜN DOĞARKEN"]
const CHAPTER_LINES := [
	"Gece yeni başladı. İskelede her şey olağan görünüyor.",
	"Yağmurla gelen bir mektup, eski bir yolcunun izini taşıyor.",
	"İskele saatleri birbirini tutmuyor. Birileri bunu fark etmiş.",
	"Kayıp emanetlerin listesi uzuyor; teslim kodlarına dikkat et.",
	"Bir koltuk her gece boş kalıyor. Yolcular aynı ismi fısıldıyor.",
	"Sis çöktü. Uzaktaki sinyallerin hangisinin gerçek olduğunu çöz.",
	"Nöbet defterindeki eksik sayfa, önceki kararlarını sorgulatıyor.",
	"Vapurun arka güvertesinde anlatılanlar öncekilerle çelişiyor.",
	"İskeleden ayrılanlar geri dönmeye başladı; kimi sana güveniyor, kimi değil.",
	"Gün doğmadan son dosyalar. Bu geceki itibarın finali belirleyecek."
]

var PASSENGERS: Array[Dictionary] = [
	{
		"name": "Deniz Aksoy", "role": "Gece hemşiresi", "route": "Kadıköy → Karaköy",
		"portrait": Color("#b98670"), "coat": Color("#6d8e91"),
		"dialogue": "Vardiyam bitti. Karaköy'deki evime dönmem gerek; sabah erkenden yine hastanedeyim.",
		"ticket": "Karaköy varışlı, bu gece 03.30 seferine kesilmiş. İsim ve tarih eşleşiyor.",
		"clues": [
			{"title": "Personel kartı", "body": "Hastane kartında Deniz Aksoy yazıyor. Fotoğraf yolcuyla eşleşiyor; kartın tarihi geçerli."},
			{"title": "Termos", "body": "Üzerinde hastanenin adı var. İçinde soğumuş çay kalmış; uzun bir vardiyadan çıkmış gibi."},
			{"title": "Bilet", "body": "Bilet Karaköy'e ve bu geceki sefere ait. Yolcunun anlattığı güzergâhla tutarlı."}
		],
		"questions": [
			{"q": "Vardiyan kaçta bitti?", "a": "İkiyi biraz geçiyordu. Otobüsü kaçırınca buraya yürüdüm."},
			{"q": "Karaköy'de nereye gideceksin?", "a": "Şişhane tarafındaki evime. Bu saatte sokaklar sessiz oluyor."},
			{"q": "Termosunda ne var?", "a": "Sabah koyduğum çay. Nöbette içmeye fırsat bulamadım."}
		],
		"case_note": "Bilet bu geceki sefere kesilmiş; hastane kartındaki isim yolcuyla eşleşiyor.",
		"key_clues": [-1, 0],
		"allow": true
	},
	{
		"name": "Rauf Yılmaz", "role": "Seyyar saatçi", "route": "Kadıköy → Karaköy",
		"portrait": Color("#c99c74"), "coat": Color("#727d92"),
		"dialogue": "Biletim Karaköy'e. Orada bekleyen bir müşteriye saat teslim edeceğim, hepsi bu.",
		"ticket": "Bilet bu geceye ait, ancak varış noktası Üsküdar. Yolcu Karaköy dedi.",
		"clues": [
			{"title": "Tamir çantası", "body": "İçinde saatçi aletleri ve kapağı açık bir cep saati var. Mesleğiyle uyumlu; bu tek başına şüphe nedeni değil."},
			{"title": "Bilet", "body": "Bilet Üsküdar'a kesilmiş. Yolcu Karaköy'e gideceğini söyledi. Seferin rotasında Üsküdar yok."},
			{"title": "Müşteri notu", "body": "Kâğıtta 'Üsküdar iskelesi, sabah 6' yazıyor. Söylediği Karaköy teslimatıyla uyuşmuyor."}
		],
		"questions": [
			{"q": "Biletin neden Üsküdar'a?", "a": "Yanlış almışım. Aslında Karaköy demek istemiştim."},
			{"q": "Müşterin nerede bekliyor?", "a": "Şey... iskeleye yakın bir yerde. Adresi yanımda değil."},
			{"q": "Çantanda ne taşıyorsun?", "a": "Saat tamir takımlarım. Bütün gün yanımdalar."}
		],
		"case_note": "Bilet Üsküdar'a, not da Üsküdar iskelesine ait; yolcu ise Karaköy'e gideceğini söylüyor.",
		"key_clues": [-1, 2],
		"allow": false
	},
	{
		"name": "Mina Erdem", "role": "Üniversite öğrencisi", "route": "Kadıköy → Karaköy",
		"portrait": Color("#d1a17f"), "coat": Color("#a4656c"),
		"dialogue": "Sergi kurulumundan çıkıyorum. Bu kutuyu sabaha kadar okula ulaştırmam lazım.",
		"ticket": "Karaköy varışlı. Bilet saati ve yolcu bilgileri doğru.",
		"clues": [
			{"title": "Öğrenci kartı", "body": "Güzel sanatlar fakültesi kartı Mina Erdem adına. Fotoğraf ve geçerlilik tarihi uygun."},
			{"title": "Karton maket", "body": "Kutunun içindeki küçük iskele maketi yarım kalmış. Üzerinde okul atölyesinin etiketi var."},
			{"title": "Bilet", "body": "Bilet bu geceki sefere ve Karaköy'e ait. Yolcunun anlattığı yolculukla örtüşüyor."}
		],
		"questions": [
			{"q": "Kutuda ne var?", "a": "Dönem projem. Maketin bir parçası gevşedi, vapurda dikkatli taşıyacağım."},
			{"q": "Okula neden bu saatte gidiyorsun?", "a": "Sabah jüri var. Maketi atölyeye bırakıp birkaç saat uyuyacağım."},
			{"q": "Sergi neredeydi?", "a": "Kadıköy'de küçük bir galeride. Kurulum geç bitti."}
		],
		"case_note": "Öğrenci kartı, atölye etiketi ve bu geceki Karaköy bileti Mina'nın anlattıklarını destekliyor.",
		"key_clues": [-1, 0],
		"allow": true
	},
	{
		"name": "Cemil Arslan", "role": "Balıkçı", "route": "Kadıköy → Karaköy",
		"portrait": Color("#a9785f"), "coat": Color("#647c73"),
		"dialogue": "Sabah hâlinde erkenden dükkânı açacağım. Her zamanki gibi ilk vapura yetişiyorum.",
		"ticket": "Karaköy varışlı bilet. Üzerindeki tarih ve sefer saati doğru.",
		"clues": [
			{"title": "Balıkçı önlüğü", "body": "Önlükte balık pulu ve buz izleri var. Yolcunun sabah dükkân açacağı iddiasını destekliyor."},
			{"title": "Kasa etiketi", "body": "Boş kasanın etiketinde Karaköy Balık Hali ve Cemil Arslan yazıyor."},
			{"title": "Bilet", "body": "Bilet doğru iskeleye ve bu geceki sefere ait. Belgelerde çelişki yok."}
		],
		"questions": [
			{"q": "Dükkânın nerede?", "a": "Karaköy Balık Hali'nin arka sırasında. Yirmi yıldır aynı yerdeyim."},
			{"q": "Kasada ne var?", "a": "Akşamdan kalan boş kasa. Sabah yeni avı taşımak için lazım."},
			{"q": "Kaçta açacaksın?", "a": "Gün doğmadan. Mal gelmeden tezgâhı hazırlamam gerek."}
		],
		"case_note": "Bilet bu geceye ait; kasa etiketi ve balıkçı önlüğü Karaköy'deki dükkânını doğruluyor.",
		"key_clues": [-1, 1],
		"allow": true
	},
	{
		"name": "Selin Vural", "role": "Yolcu", "route": "Kadıköy → Karaköy",
		"portrait": Color("#d5ad91"), "coat": Color("#566a8e"),
		"dialogue": "Beni içeride bekliyorlar. Biletimi kaybettim ama görevli olduğumu söyleyebilirsiniz.",
		"ticket": "Yolcu bilet gösteremiyor. Cebinden çıkan bilet başka bir isme ve dünkü tarihe ait.",
		"clues": [
			{"title": "Bilet parçası", "body": "Bulunan bilet dünkü sefere ve başka bir yolcuya ait. Bu gece için geçerli değil."},
			{"title": "İsimsiz anahtar", "body": "Üzerinde adres ya da isim olmayan tek bir anahtar. Yolcunun görevli olduğu iddiasını doğrulamıyor."},
			{"title": "Islak not", "body": "Notta yalnızca 'kapı açık kalacak' yazıyor. Kime ait olduğu anlaşılmıyor; tek başına kanıt sayılmaz."}
		],
		"questions": [
			{"q": "Kiminle buluşacaksın?", "a": "İsmini veremem. Beni bekliyorlar, lütfen vakit kaybetmeyelim."},
			{"q": "Bilet neden başka birinin?", "a": "Yerde buldum. Benim biletim buydu sanırım."},
			{"q": "Görevli olduğunu kanıtlayabilir misin?", "a": "Kartım yanımda değil. Herkes beni tanır."}
		],
		"case_note": "Cebindeki bilet başka birinin ve dünkü seferin. Yolcunun görevli olduğu iddiasını doğrulayacak belge yok.",
		"key_clues": [-1, 0],
		"allow": false
	}
]

var current_passenger := 0
var score := 0
var inspected: Dictionary = {}
var asked_question := -1
var screen_root: Control
var text_scale := 1.15
var high_contrast := false
var settings := ConfigFile.new()
var trust := 50
var decision_history: Array[Dictionary] = []
var story_evidence: Array[String] = []
var case_order: Array[int] = []
var solved_evidence_cases: Array[int] = []
var achievements: Array[String] = []
var endings_seen: Array[String] = []
var correct_streak := 0
var difficulty_mode := 1
var remaining_seconds := 0
var case_timer: Timer
var timer_label: Label
var selected_evidence: Array[int] = []
var evidence_board_feedback := ""
var steam_bridge: Node
var steam_test_feedback := ""
var weather_chapter := 0
var ambient_enabled := true
var ambience_player: AudioStreamPlayer
var backdrop
var notebook_return_view := "case"


class NightBackdrop extends Control:
	var phase := 0.0
	var chapter := 1

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		queue_redraw()

	func set_chapter(value: int) -> void:
		chapter = value
		queue_redraw()

	func _process(delta: float) -> void:
		phase += delta
		queue_redraw()

	func _draw() -> void:
		var w := size.x
		var h := size.y
		var dawn := clampf(float(chapter - 1) / 9.0, 0.0, 1.0)
		var sky := Color("#071426").lerp(Color("#172d43"), dawn * 0.52)
		draw_rect(Rect2(Vector2.ZERO, size), sky)
		draw_rect(Rect2(0, h * 0.48, w, h * 0.52), Color("#0a2034").lerp(Color("#173348"), dawn * 0.35))
		var glow := 0.045 + sin(phase * 1.3) * 0.008
		draw_circle(Vector2(w * 0.82, h * 0.18), 42.0, Color("#f2c879"))
		draw_circle(Vector2(w * 0.82, h * 0.18), 65.0, Color(0.95, 0.78, 0.47, glow))
		for i in range(34):
			var x := fposmod(float(i * 173 + 47), maxf(w, 1.0))
			var y := fposmod(float(i * 89 + 19), h * 0.44)
			var star_alpha := (0.52 - dawn * 0.42) * (0.75 + sin(phase * 1.7 + float(i)) * 0.25)
			draw_circle(Vector2(x, y), 1.2 if i % 3 == 0 else 0.8, Color(0.9, 0.88, 0.74, star_alpha))
		# Each chapter changes the weather; rain and low fog are drawn procedurally.
		var rain_count := 8 + (chapter % 4) * 8
		for i in range(rain_count):
			var rx := fposmod(float(i * 113) + phase * (62.0 + float(chapter % 3) * 17.0), maxf(w, 1.0))
			var ry := fposmod(float(i * 71) + phase * 95.0, maxf(h * 0.9, 1.0))
			draw_line(Vector2(rx, ry), Vector2(rx - 5.0, ry + 13.0), Color(0.69, 0.82, 0.91, 0.13 + float(chapter % 3) * 0.035), 1.0)
		for layer in range(3):
			var fog_x := fposmod(phase * (12.0 + float(layer) * 6.0) + float(layer) * w * 0.37, w + 420.0) - 210.0
			var fog_y := h * (0.59 + float(layer) * 0.045)
			draw_rect(Rect2(fog_x, fog_y, w * 0.43, 22.0), Color(0.66, 0.77, 0.82, 0.035 + float(chapter % 4) * 0.012))
		for i in range(9):
			var y := h * 0.58 + float(i) * 31.0 + sin(phase * 1.1 + float(i)) * 2.0
			var x := fposmod(float(i * 211 + 76) + phase * (8.0 + float(i % 4) * 2.0), maxf(w - 100.0, 1.0))
			draw_line(Vector2(x, y), Vector2(x + 45.0 + float(i % 4) * 18.0, y), Color(0.48, 0.69, 0.72, 0.17), 1.0)
		draw_colored_polygon(PackedVector2Array([
			Vector2(0, h * 0.79), Vector2(w * 0.19, h * 0.79),
			Vector2(w * 0.25, h * 0.87), Vector2(w * 0.25, h), Vector2(0, h)
		]), Color("#101b29"))
		draw_colored_polygon(PackedVector2Array([
			Vector2(w * 0.71, h * 0.78), Vector2(w, h * 0.78),
			Vector2(w, h), Vector2(w * 0.74, h), Vector2(w * 0.74, h * 0.89)
		]), Color("#101b29"))
		for i in range(4):
			var wx := w * 0.76 + float(i % 2) * 45.0
			var wy := h * 0.83 + float(i / 2) * 38.0
			draw_rect(Rect2(wx, wy, 17, 22), Color(0.95, 0.72, 0.36, 0.3 + sin(phase * 2.0 + float(i)) * 0.07))


class HarborAmbience extends AudioStreamPlayer:
	var playback: AudioStreamGeneratorPlayback
	var phase := 0.0
	var noise_state := 0.37
	var enabled := true
	var chapter := 1

	func _ready() -> void:
		var generator := AudioStreamGenerator.new()
		generator.mix_rate = 22050.0
		generator.buffer_length = 0.35
		stream = generator
		volume_db = -25.0 if enabled else -80.0
		play()
		playback = get_stream_playback() as AudioStreamGeneratorPlayback

	func set_enabled(value: bool) -> void:
		enabled = value
		volume_db = -25.0 if enabled else -80.0

	func set_chapter(value: int) -> void:
		chapter = value

	func _process(_delta: float) -> void:
		if playback == null:
			return
		var available := playback.get_frames_available()
		for i in range(available):
			noise_state = fposmod(noise_state * 3.987 + 0.071, 1.0)
			var hum := sin(phase) * 0.013 + sin(phase * 0.41) * 0.006 + sin(phase * 1.63) * 0.0025
			var soft_water := (noise_state - 0.5) * (0.0025 + float(chapter % 4) * 0.0007)
			var sample := hum + soft_water
			playback.push_frame(Vector2(sample, sample))
			phase += TAU * (48.0 + float(chapter % 5) * 3.0) / 22050.0


class TravellerPortrait extends Control:
	var skin := Color("#bd8f73")
	var coat := Color("#627b81")
	var person_index := 0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var center := Vector2(size.x * 0.5, size.y * 0.48)
		var scale_factor := minf(size.x, size.y) / 230.0
		draw_circle(center, 96.0 * scale_factor, Color(0.95, 0.79, 0.48, 0.08))
		draw_circle(center + Vector2(0, 20 * scale_factor), 78.0 * scale_factor, Color("#17344a"))
		draw_colored_polygon(PackedVector2Array([
			center + Vector2(-76, 120) * scale_factor,
			center + Vector2(-54, 54) * scale_factor,
			center + Vector2(0, 37) * scale_factor,
			center + Vector2(54, 54) * scale_factor,
			center + Vector2(76, 120) * scale_factor
		]), coat)
		draw_rect(Rect2(center + Vector2(-17, 27) * scale_factor, Vector2(34, 35) * scale_factor), skin)
		draw_circle(center + Vector2(0, -18) * scale_factor, 46.0 * scale_factor, skin)
		var hair_color := Color("#302a2b") if person_index % 2 == 0 else Color("#46302c")
		draw_arc(center + Vector2(0, -22) * scale_factor, 47.0 * scale_factor, PI, TAU, 32, hair_color, 13.0 * scale_factor, true)
		if person_index % 2 == 1:
			draw_circle(center + Vector2(-43, 10) * scale_factor, 11.0 * scale_factor, hair_color)
			draw_circle(center + Vector2(43, 10) * scale_factor, 11.0 * scale_factor, hair_color)
		draw_circle(center + Vector2(-15, -15) * scale_factor, 2.8 * scale_factor, Color("#15202a"))
		draw_circle(center + Vector2(15, -15) * scale_factor, 2.8 * scale_factor, Color("#15202a"))
		draw_line(center + Vector2(-8, 8) * scale_factor, center + Vector2(8, 8) * scale_factor, Color("#71483e"), 2.0 * scale_factor)
		if person_index == 3:
			draw_line(center + Vector2(-52, 5) * scale_factor, center + Vector2(52, 5) * scale_factor, Color("#d5c18e"), 3.0 * scale_factor)


class BoardingAnimation extends Control:
	signal completed
	var permitted := true
	var progress := 0.0
	var gait := 0.0
	var person_index := 0
	var skin := Color("#bd8f73")
	var coat := Color("#607d82")

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func play(can_board: bool) -> void:
		permitted = can_board
		progress = 0.0
		var tween := create_tween()
		tween.tween_property(self, "progress", 1.0, 2.8).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
		tween.finished.connect(func(): completed.emit())

	func _process(delta: float) -> void:
		gait += delta * 11.0
		queue_redraw()

	func _draw() -> void:
		var w := size.x
		var h := size.y
		draw_rect(Rect2(Vector2.ZERO, size), Color("#0a1d30"))
		draw_rect(Rect2(0, h * 0.56, w, h * 0.44), Color("#0b293a"))
		draw_circle(Vector2(w * 0.84, h * 0.18), 23.0, Color("#f2c879"))
		for i in range(7):
			var ripple_x := fposmod(float(i * 139 + int(gait * 5)), maxf(w, 1.0))
			draw_line(Vector2(ripple_x, h * 0.66 + float(i % 3) * 24.0), Vector2(ripple_x + 44.0, h * 0.66 + float(i % 3) * 24.0), Color(0.58, 0.78, 0.8, 0.22), 2.0)
		# Ferry hull and illuminated cabin.
		draw_colored_polygon(PackedVector2Array([
			Vector2(w * 0.68, h * 0.42), Vector2(w * 0.97, h * 0.42),
			Vector2(w * 0.91, h * 0.68), Vector2(w * 0.74, h * 0.68)
		]), Color("#d4d5cc"))
		draw_rect(Rect2(w * 0.74, h * 0.24, w * 0.16, h * 0.18), Color("#e8e1d0"))
		draw_rect(Rect2(w * 0.77, h * 0.29, w * 0.035, h * 0.07), Color("#e9bd70"))
		draw_rect(Rect2(w * 0.83, h * 0.29, w * 0.035, h * 0.07), Color("#e9bd70"))
		draw_rect(Rect2(w * 0.87, h * 0.29, w * 0.022, h * 0.07), Color("#e9bd70"))
		draw_rect(Rect2(w * 0.71, h * 0.39, w * 0.28, h * 0.035), Color("#f2c879"))
		# Pier, mooring posts, and the boarding ramp.
		draw_rect(Rect2(0, h * 0.76, w * 0.71, h * 0.24), Color("#302d2c"))
		for i in range(8):
			var plank_x := float(i) * w * 0.09
			draw_line(Vector2(plank_x, h * 0.77), Vector2(plank_x, h), Color(0.77, 0.69, 0.56, 0.16), 2.0)
		draw_line(Vector2(w * 0.64, h * 0.77), Vector2(w * 0.74, h * 0.44), Color("#9a8a6e"), 11.0)
		draw_line(Vector2(w * 0.66, h * 0.75), Vector2(w * 0.76, h * 0.42), Color("#e0c88d"), 2.0)
		draw_rect(Rect2(w * 0.07, h * 0.44, 7, h * 0.33), Color("#aa8655"))
		draw_circle(Vector2(w * 0.073, h * 0.43), 16.0, Color(0.95, 0.72, 0.36, 0.14))
		draw_circle(Vector2(w * 0.073, h * 0.43), 7.0, Color("#f2c879"))
		var t := clampf((progress - 0.5) / 0.5, 0.0, 1.0) if permitted else 0.0
		var start_x := w * 0.2
		var end_x := w * 0.77 if permitted else w * 0.06
		var px := lerpf(start_x, end_x, progress)
		var py := h * 0.76 - t * h * 0.25
		var step := sin(gait) * 9.0 * (1.0 - progress * 0.35)
		var arm_swing := cos(gait) * 8.0
		var body := Vector2(px, py)
		# A softly lit, code-drawn traveller with a visible walking cycle.
		draw_circle(body + Vector2(0, 4), 8.0, Color(0, 0, 0, 0.27))
		draw_line(body + Vector2(-5, -3), body + Vector2(-8 + step, 23), Color("#28313a"), 8.0)
		draw_line(body + Vector2(5, -3), body + Vector2(8 - step, 23), Color("#28313a"), 8.0)
		draw_line(body + Vector2(-13, -44), body + Vector2(-23 - arm_swing, -15), coat.lightened(0.08), 7.0)
		draw_line(body + Vector2(13, -44), body + Vector2(23 + arm_swing, -15), coat.lightened(0.08), 7.0)
		draw_colored_polygon(PackedVector2Array([
			body + Vector2(-18, -53), body + Vector2(18, -53),
			body + Vector2(21, -6), body + Vector2(-21, -6)
		]), coat)
		draw_circle(body + Vector2(0, -73), 17.0, skin)
		draw_arc(body + Vector2(0, -77), 18.0, PI, TAU, 20, Color("#352b2a"), 7.0, true)
		if person_index % 3 == 0:
			draw_rect(Rect2(body + Vector2(19 + arm_swing, -22), Vector2(17, 14)), Color("#765741"))
			draw_line(body + Vector2(22 + arm_swing, -24), body + Vector2(32 + arm_swing, -24), Color("#b69c72"), 2.0)
		if permitted:
			draw_circle(body + Vector2(-5, -74), 1.5, Color("#17212a"))
			draw_circle(body + Vector2(5, -74), 1.5, Color("#17212a"))
			draw_arc(body + Vector2(0, -68), 5.0, 0.2, PI - 0.2, 12, Color("#805345"), 1.5)
		else:
			draw_line(body + Vector2(-9, -80), body + Vector2(-3, -77), Color("#49302d"), 2.0)
			draw_line(body + Vector2(3, -77), body + Vector2(9, -80), Color("#49302d"), 2.0)
			draw_circle(body + Vector2(-5, -73), 1.5, Color("#17212a"))
			draw_circle(body + Vector2(5, -73), 1.5, Color("#17212a"))
			draw_arc(body + Vector2(0, -63), 5.0, PI + 0.25, TAU - 0.25, 12, Color("#71473f"), 1.7)
			if progress > 0.78:
				draw_line(body + Vector2(0, -98), body + Vector2(9, -109), Color("#e58d7d"), 2.0)
				draw_line(body + Vector2(0, -98), body + Vector2(-8, -108), Color("#e58d7d"), 2.0)


func _ready() -> void:
	var returning_people: Array[Dictionary] = PASSENGERS.duplicate()
	PASSENGERS.append_array(CaseBank.make_cases(PASSENGERS.size(), 95, returning_people))
	var finale: Dictionary = PASSENGERS[99]
	finale["name"] = "Nihat Korkut"
	finale["role"] = "Eski gece vardiyası şefi"
	finale["route"] = "Kadıköy → Karaköy"
	finale["dialogue"] = "Saatleri ben değiştirdim. Önce kararını ver; nöbet defterinin son sayfası sana nedenini anlatacak."
	finale["ticket"] = "Bu gece 03.30 seferine kesilmiş. Eski vardiya rozeti biletin arkasına iliştirilmiş."
	var final_fragment: String = finale["fragment"]
	finale["clues"] = [
		{"title": "Vardiya rozeti", "body": "Nihat Korkut'un eski gece amiri rozeti. Fotoğrafı yolcuyla eşleşiyor, ancak rozet yıllar önce teslim edilmiş olmalı."},
		{"title": "Saat bakım fişi", "body": "On iki dakikalık ayar değişikliğinin Nihat tarafından yapıldığını doğruluyor. Fișin tarihi, son vapurun kaybolduğu sisli geceyle aynı."},
		{"title": "Kaptan notu", "body": "'Üç kısa ışık gelene kadar bekle' yazıyor. Kaptan notta imza atmış, fakat resmi nöbet kaydına işlenmemiş."},
		{"title": "Nöbet defterinin son sayfası", "body": final_fragment}
	]
	finale["questions"] = [
		{"q": "Saati sen mi değiştirdin?", "a": "Evet. On iki dakika ileri aldım; ama son vapurun neden beklediğini defter anlatıyor."},
		{"q": "Neden resmi kayda yazmadın?", "a": "İşaret gelmeden vapur kalkmasın istedim. O gece kıyıda bir çocuk vardı."},
		{"q": "Neden şimdi anlatıyorsun?", "a": "Son sayfayı bulduğunu görünce artık saklamanın anlamı kalmadı."}
	]
	finale["case_question"] = "Eski gece şefi bu gece vapura alınmalı mı?"
	finale["case_note"] = "Nihat'ın bu gece için geçerli bileti ve kimliği var. Saati değiştirdiğini kabul ediyor; nöbet defterindeki işaretler bunun bir kurtarma bekleyişi olduğunu gösteriyor."
	finale["key_clues"] = [-1, 2]
	finale["allow"] = true
	finale["returning"] = false
	settings.load("user://son_sefer.cfg")
	_prepare_case_order(false)
	text_scale = float(settings.get_value("accessibility", "text_scale", 1.15))
	high_contrast = bool(settings.get_value("accessibility", "high_contrast", false))
	ambient_enabled = bool(settings.get_value("accessibility", "ambient_enabled", true))
	difficulty_mode = clampi(int(settings.get_value("gameplay", "difficulty_mode", 1)), 0, 2)
	trust = int(settings.get_value("progress", "trust", 50))
	correct_streak = int(settings.get_value("progress", "correct_streak", 0))
	var stored_history: Array = settings.get_value("progress", "history", [])
	for item in stored_history:
		if item is Dictionary:
			decision_history.append(item)
	var stored_evidence: Array = settings.get_value("progress", "story_evidence", [])
	for clue in stored_evidence:
		if clue is String:
			story_evidence.append(clue)
	var stored_order: Array = settings.get_value("progress", "case_order", [])
	if stored_order.size() == PASSENGERS.size():
		case_order.clear()
		for case_id in stored_order:
			case_order.append(clampi(int(case_id), 0, PASSENGERS.size() - 1))
	var stored_solved: Array = settings.get_value("progress", "solved_evidence_cases", [])
	for case_id in stored_solved:
		solved_evidence_cases.append(int(case_id))
	achievements.assign(settings.get_value("meta", "achievements", []))
	endings_seen.assign(settings.get_value("meta", "endings_seen", []))
	backdrop = NightBackdrop.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(backdrop)
	backdrop.queue_redraw()
	ambience_player = HarborAmbience.new()
	ambience_player.enabled = ambient_enabled
	add_child(ambience_player)
	case_timer = Timer.new()
	case_timer.wait_time = 1.0
	case_timer.timeout.connect(_tick_case_timer)
	add_child(case_timer)
	steam_bridge = SteamBridgeScript.new()
	add_child(steam_bridge)
	if bool(steam_bridge.get("connected")):
		for achievement_id in achievements:
			steam_bridge.call("unlock", achievement_id)
	backdrop.set_chapter(1)
	ambience_player.set_chapter(1)
	_show_title()


func _prepare_case_order(shuffle_chapters: bool) -> void:
	case_order.clear()
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for chapter in range(10):
		var chapter_cases: Array[int] = []
		for offset in range(9):
			chapter_cases.append(chapter * 10 + offset)
		if shuffle_chapters:
			for i in range(chapter_cases.size() - 1, 0, -1):
				var j := rng.randi_range(0, i)
				var swap_value := chapter_cases[i]
				chapter_cases[i] = chapter_cases[j]
				chapter_cases[j] = swap_value
		case_order.append_array(chapter_cases)
		# Keep each chapter's hidden page for its final case.
		case_order.append(chapter * 10 + 9)


func _current_case_id() -> int:
	if current_passenger >= 0 and current_passenger < case_order.size():
		return case_order[current_passenger]
	return clampi(current_passenger, 0, PASSENGERS.size() - 1)


func _current_case() -> Dictionary:
	return PASSENGERS[_current_case_id()]


func _make_screen() -> VBoxContainer:
	if is_instance_valid(screen_root):
		screen_root.queue_free()
	screen_root = Control.new()
	screen_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(screen_root)
	var margins := MarginContainer.new()
	margins.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margins.add_theme_constant_override("margin_left", 42)
	margins.add_theme_constant_override("margin_right", 42)
	margins.add_theme_constant_override("margin_top", 28)
	margins.add_theme_constant_override("margin_bottom", 28)
	screen_root.add_child(margins)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 16)
	margins.add_child(column)
	return column


func _show_title() -> void:
	_pause_case_clock()
	var column := _make_screen()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	var eyebrow := _label("MARMARA HATTI     •     GECE SEFERİ 03:30", 13, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(eyebrow)
	var title := _label("SON SEFER", 58, CREAM, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(title)
	var subtitle := _label("GECE VARDİYASI     /     100 YOLCU DOSYASI", 17, TEAL, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(subtitle)
	var gap := Control.new()
	gap.custom_minimum_size.y = 18
	column.add_child(gap)
	var card := _panel(PANEL, 680)
	card.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	column.add_child(card)
	var inside := _margin_inside(card, 24)
	var intro := _label("Son vapur kalkmak üzere. Yüz yolcunun dosyasını incele;\nbiletleri, ifadeleri ve küçük ayrıntıları karşılaştır.\nHer karar sabaha nasıl ulaşacağını belirleyecek.", 19, CREAM, HORIZONTAL_ALIGNMENT_CENTER)
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inside.add_child(intro)
	var new_game := _button("YENİ VARDİYA", true)
	new_game.custom_minimum_size.y = 56
	new_game.pressed.connect(_begin_shift)
	inside.add_child(new_game)
	if _has_save():
		var resume := _button("KALDIĞIN YERDEN DEVAM ET", false)
		resume.custom_minimum_size.y = 48
		resume.pressed.connect(_resume_shift)
		inside.add_child(resume)
	var menu_row := HBoxContainer.new()
	menu_row.add_theme_constant_override("separation", 10)
	inside.add_child(menu_row)
	var options := _button("AYARLAR", false)
	options.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	options.pressed.connect(_show_settings)
	menu_row.add_child(options)
	var guide := _button("NASIL OYNANIR", false)
	guide.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	guide.pressed.connect(_show_how_to)
	menu_row.add_child(guide)
	var credits := _button("HAKKINDA", false)
	credits.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	credits.pressed.connect(_show_credits)
	menu_row.add_child(credits)
	var achievements_button := _button("BAŞARIMLAR", false)
	achievements_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	achievements_button.pressed.connect(_show_achievements)
	menu_row.add_child(achievements_button)
	if not decision_history.is_empty():
		var notebook := _button("VARDİYA DEFTERİ", false)
		notebook.pressed.connect(_open_notebook.bind("menu"))
		inside.add_child(notebook)
	var quit := _button("ÇIKIŞ", false)
	quit.pressed.connect(func(): get_tree().quit())
	inside.add_child(quit)


func _show_settings() -> void:
	_pause_case_clock()
	var column := _make_screen()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_child(_label("AYARLAR", 38, CREAM, HORIZONTAL_ALIGNMENT_CENTER))
	var card := _panel(PANEL, 620)
	card.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	column.add_child(card)
	var inside := _margin_inside(card, 22)
	inside.add_child(_label("OKUNABİLİRLİK", 14, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	var size_row := HBoxContainer.new()
	size_row.add_theme_constant_override("separation", 10)
	inside.add_child(size_row)
	var smaller := _button("YAZIYI KÜÇÜLT", false)
	smaller.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	smaller.pressed.connect(func(): _change_text_scale(-0.1))
	size_row.add_child(smaller)
	var size_label := _label("YAZI BOYUTU  %d%%" % int(text_scale * 100.0), 16, CREAM, HORIZONTAL_ALIGNMENT_CENTER)
	size_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_row.add_child(size_label)
	var larger := _button("YAZIYI BÜYÜT", false)
	larger.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	larger.pressed.connect(func(): _change_text_scale(0.1))
	size_row.add_child(larger)
	var contrast := _button("YÜKSEK KONTRAST: %s" % ("AÇIK" if high_contrast else "KAPALI"), true)
	contrast.custom_minimum_size.y = 48
	contrast.pressed.connect(func():
		high_contrast = not high_contrast
		_save_settings()
		_show_settings()
	)
	inside.add_child(contrast)
	var sound := _button("İSKELE AMBİYANSI: %s" % ("AÇIK" if ambient_enabled else "KAPALI"), false)
	sound.custom_minimum_size.y = 48
	sound.pressed.connect(_toggle_ambient)
	inside.add_child(sound)
	inside.add_child(_label("VARDİYA ZORLUĞU", 14, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	var difficulty_row := HBoxContainer.new()
	difficulty_row.add_theme_constant_override("separation", 9)
	inside.add_child(difficulty_row)
	var modes := ["RAHAT • SÜRESİZ", "NORMAL • 90 SN", "ZOR • 45 SN"]
	for i in range(modes.size()):
		var mode_button := _button(modes[i], difficulty_mode == i)
		mode_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		mode_button.custom_minimum_size.y = 48
		mode_button.pressed.connect(_set_difficulty.bind(i))
		difficulty_row.add_child(mode_button)
	inside.add_child(_label("Metin gölgelerini kaldırdım ve temel yazı boyutlarını büyüttüm.\nAyarlar bu bilgisayarda saklanır.", 14, MUTED, HORIZONTAL_ALIGNMENT_CENTER))
	var back := _button("ANA MENÜYE DÖN", false)
	back.pressed.connect(_show_title)
	inside.add_child(back)


func _change_text_scale(amount: float) -> void:
	text_scale = clampf(text_scale + amount, 0.9, 1.6)
	_save_settings()
	_show_settings()


func _save_settings() -> void:
	settings.set_value("accessibility", "text_scale", text_scale)
	settings.set_value("accessibility", "high_contrast", high_contrast)
	settings.set_value("accessibility", "ambient_enabled", ambient_enabled)
	settings.set_value("gameplay", "difficulty_mode", difficulty_mode)
	settings.save("user://son_sefer.cfg")


func _set_difficulty(mode: int) -> void:
	difficulty_mode = clampi(mode, 0, 2)
	_save_settings()
	_show_settings()


func _toggle_ambient() -> void:
	ambient_enabled = not ambient_enabled
	if is_instance_valid(ambience_player):
		ambience_player.set_enabled(ambient_enabled)
	_save_settings()
	_show_settings()


func _show_how_to() -> void:
	_pause_case_clock()
	var column := _make_screen()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_child(_label("NASIL OYNANIR", 36, CREAM, HORIZONTAL_ALIGNMENT_CENTER))
	var card := _panel(PANEL, 700)
	card.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	column.add_child(card)
	var inside := _margin_inside(card, 24)
	var copy := _label("Her dosyada yolcunun ifadesini, biletini ve ipuçlarını incele. Zorluk ilerledikçe yanıltıcı yan kayıtlar da çıkar.\n\nBir ek soru sorabilirsin; seçtiğin soru hakkını tüketir. İsim, tarih, güzergâh, saat ve kayıt numaralarını karşılaştır.\n\nHer bölümün son dosyasında yırtık bir nöbet sayfası saklı. Sayfaları buldukça deftere eklenir ve gizli hikâyeyi açar.\n\nVapura alırsan yolcu gemiye yürür. İzin vermezsen sinirlenip iskeleden çıkar. Önceki kararların geri dönen yolcuların tavrını ve iskele güvenini etkiler.\n\nYüz dosyanın sonunda puanın, iskele güvenin ve bulduğun sayfalara göre bir final göreceksin.", 17, CREAM)
	copy.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inside.add_child(copy)
	var back := _button("ANA MENÜYE DÖN", true)
	back.pressed.connect(_show_title)
	inside.add_child(back)


func _show_credits() -> void:
	_pause_case_clock()
	var column := _make_screen()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_child(_label("HAKKINDA", 36, CREAM, HORIZONTAL_ALIGNMENT_CENTER))
	var card := _panel(PANEL, 600)
	card.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	column.add_child(card)
	var inside := _margin_inside(card, 24)
	inside.add_child(_label("SON SEFER: GECE VARDİYASI\n\nKodla çizilmiş tek kişilik bir karar oyunu.\nGodot ile geliştirildi.\n\nHer yolcunun hikâyesini dikkatle dinle.", 18, CREAM, HORIZONTAL_ALIGNMENT_CENTER))
	var back := _button("ANA MENÜYE DÖN", false)
	back.pressed.connect(_show_title)
	inside.add_child(back)


func _show_achievements() -> void:
	_pause_case_clock()
	var column := _make_screen()
	var header := HBoxContainer.new()
	column.add_child(header)
	var title := _label("BAŞARIMLAR", 32, CREAM)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	header.add_child(_label("%d / %d AÇILDI" % [achievements.size(), ACHIEVEMENT_DEFINITIONS.size()], 15, GOLD, HORIZONTAL_ALIGNMENT_RIGHT))
	var steam_connected := is_instance_valid(steam_bridge) and bool(steam_bridge.get("connected"))
	var steam_status := String(steam_bridge.get("status_message")) if is_instance_valid(steam_bridge) else "Steam köprüsü kurulmadı."
	column.add_child(_label("STEAM API: %s" % ("BAĞLI" if steam_connected else steam_status.to_upper()), 13, TEAL if steam_connected else MUTED))
	if not steam_test_feedback.is_empty():
		column.add_child(_label(steam_test_feedback, 13, GOLD))
	if OS.is_debug_build():
		var test_row := HBoxContainer.new()
		test_row.add_theme_constant_override("separation", 8)
		var local_unlock := _button("ÜCRETSİZ TEST: TÜM YEREL BAŞARIMLARI AÇ", true)
		local_unlock.pressed.connect(_unlock_all_local_achievements)
		test_row.add_child(local_unlock)
		var local_clear := _button("YEREL TESTİ SIFIRLA", false)
		local_clear.pressed.connect(_clear_local_achievements)
		test_row.add_child(local_clear)
		column.add_child(test_row)
	if OS.is_debug_build() and steam_connected:
		var test_row := HBoxContainer.new()
		test_row.add_theme_constant_override("separation", 8)
		var test_unlock := _button("STEAM TESTİ: İLK DÜDÜK AÇ", true)
		test_unlock.pressed.connect(_test_steam_achievement)
		test_row.add_child(test_unlock)
		var test_clear := _button("TEST BAŞARIMINI SIFIRLA", false)
		test_clear.pressed.connect(_clear_steam_test_achievement)
		test_row.add_child(test_clear)
		column.add_child(test_row)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(scroll)
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 9)
	scroll.add_child(list)
	for achievement in ACHIEVEMENT_DEFINITIONS:
		var unlocked: bool = achievements.has(achievement["id"])
		var card := _panel(Color("#15364a") if unlocked else PANEL, 0)
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		list.add_child(card)
		var inside := _margin_inside(card, 14)
		inside.add_child(_label("%s   •   %s" % ["✓" if unlocked else "○", achievement["title"]], 18, GOLD if unlocked else MUTED))
		inside.add_child(_label(achievement["description"], 14, CREAM if unlocked else MUTED))
	var back := _button("ANA MENÜYE DÖN", true)
	back.custom_minimum_size.y = 50
	back.pressed.connect(_show_title)
	column.add_child(back)


func _unlock_achievement(achievement_id: String) -> void:
	if achievements.has(achievement_id):
		return
	achievements.append(achievement_id)
	settings.set_value("meta", "achievements", achievements)
	settings.save("user://son_sefer.cfg")
	if is_instance_valid(steam_bridge) and steam_bridge.has_method("unlock"):
		steam_bridge.call("unlock", achievement_id)


func _test_steam_achievement() -> void:
	var stored := bool(steam_bridge.call("unlock", "FIRST_DUTY"))
	steam_test_feedback = "Steam FIRST_DUTY isteği gönderildi." if stored else "Açılmadı: App ID, yayımlanmış başarı tanımı ve Steam hesabı erişimini kontrol et."
	_show_achievements()


func _clear_steam_test_achievement() -> void:
	var cleared := bool(steam_bridge.call("clear", "FIRST_DUTY"))
	steam_test_feedback = "Test başarımı Steam'de sıfırlandı." if cleared else "Sıfırlanamadı; Steam bağlantısını ve başarı tanımını kontrol et."
	_show_achievements()


func _unlock_all_local_achievements() -> void:
	for definition in ACHIEVEMENT_DEFINITIONS:
		var achievement_id: String = definition["id"]
		if not achievements.has(achievement_id):
			achievements.append(achievement_id)
	settings.set_value("meta", "achievements", achievements)
	settings.save("user://son_sefer.cfg")
	steam_test_feedback = "Yedi yerel başarım test için açıldı; Steam profiline gönderilmedi."
	_show_achievements()


func _clear_local_achievements() -> void:
	achievements.clear()
	settings.set_value("meta", "achievements", achievements)
	settings.save("user://son_sefer.cfg")
	steam_test_feedback = "Yerel başarımlar sıfırlandı. Steam hesabındaki kayıt değişmedi."
	_show_achievements()


func _has_save() -> bool:
	var file := ConfigFile.new()
	return file.load("user://son_sefer.cfg") == OK and file.has_section_key("progress", "case_index")


func _resume_shift() -> void:
	var file := ConfigFile.new()
	if file.load("user://son_sefer.cfg") == OK:
		current_passenger = clampi(int(file.get_value("progress", "case_index", 0)), 0, PASSENGERS.size())
		score = int(file.get_value("progress", "score", 0))
		trust = int(file.get_value("progress", "trust", 50))
		remaining_seconds = int(file.get_value("progress", "remaining_seconds", _time_limit()))
		correct_streak = int(file.get_value("progress", "correct_streak", 0))
		var saved_order: Array = file.get_value("progress", "case_order", [])
		if saved_order.size() == PASSENGERS.size():
			case_order.clear()
			for case_id in saved_order:
				case_order.append(clampi(int(case_id), 0, PASSENGERS.size() - 1))
		solved_evidence_cases.clear()
		for case_id in file.get_value("progress", "solved_evidence_cases", []):
			solved_evidence_cases.append(int(case_id))
		decision_history.clear()
		var saved_history: Array = file.get_value("progress", "history", [])
		for record in saved_history:
			if record is Dictionary:
				decision_history.append(record)
		story_evidence.clear()
		var saved_evidence: Array = file.get_value("progress", "story_evidence", [])
		for clue in saved_evidence:
			if clue is String:
				story_evidence.append(clue)
		inspected.clear()
		asked_question = -1
		if current_passenger >= PASSENGERS.size():
			_show_ending()
		elif current_passenger % 10 == 0:
			_show_chapter_intro()
		else:
			_show_case(false)


func _begin_shift() -> void:
	_prepare_case_order(true)
	current_passenger = 0
	score = 0
	trust = 50
	correct_streak = 0
	decision_history.clear()
	story_evidence.clear()
	solved_evidence_cases.clear()
	inspected.clear()
	asked_question = -1
	settings.erase_section("progress")
	_save_settings()
	settings.set_value("progress", "case_index", 0)
	settings.set_value("progress", "score", 0)
	settings.set_value("progress", "trust", trust)
	settings.set_value("progress", "history", decision_history)
	settings.set_value("progress", "story_evidence", story_evidence)
	settings.set_value("progress", "case_order", case_order)
	settings.set_value("progress", "solved_evidence_cases", solved_evidence_cases)
	settings.set_value("progress", "remaining_seconds", _time_limit())
	settings.set_value("progress", "correct_streak", correct_streak)
	settings.save("user://son_sefer.cfg")
	_show_chapter_intro()


func _show_chapter_intro() -> void:
	_pause_case_clock()
	var chapter := clampi(int(current_passenger / 10) + 1, 1, 10)
	if is_instance_valid(backdrop):
		backdrop.set_chapter(chapter)
	if is_instance_valid(ambience_player):
		ambience_player.set_chapter(chapter)
	var column := _make_screen()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_child(_label("BÖLÜM %02d / 10" % chapter, 15, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	column.add_child(_label(CHAPTER_TITLES[chapter - 1], 42, CREAM, HORIZONTAL_ALIGNMENT_CENTER))
	var card := _panel(PANEL, 720)
	card.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	column.add_child(card)
	var inside := _margin_inside(card, 24)
	var chapter_text: String = CHAPTER_LINES[chapter - 1]
	if chapter > 1:
		var previous_correct := 0
		var previous_total := 0
		for record in decision_history:
			if int(record.get("chapter", 0)) == chapter - 1:
				previous_total += 1
				if record.get("correct", false):
					previous_correct += 1
		chapter_text += "\n\nÖNCEKİ BÖLÜM: %d / %d doğru karar. İskele güveni şimdi %d / 100." % [previous_correct, previous_total, trust]
	var chapter_copy := _label("%s\n\nBu bölümde 10 yolcu dosyası var. Önceki kararların, geri dönen yolcuların sana nasıl sesleneceğini ve iskeledeki itibarını etkiler." % chapter_text, 18, CREAM, HORIZONTAL_ALIGNMENT_CENTER)
	chapter_copy.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inside.add_child(chapter_copy)
	inside.add_child(_label("İSKELE HALKININ GÜVENİ     %d / 100" % trust, 15, TEAL, HORIZONTAL_ALIGNMENT_CENTER))
	var trust_bar := ProgressBar.new()
	trust_bar.min_value = 0
	trust_bar.max_value = 100
	trust_bar.value = trust
	trust_bar.show_percentage = false
	trust_bar.custom_minimum_size.y = 13
	var bar_bg := StyleBoxFlat.new()
	bar_bg.bg_color = Color("#203344")
	bar_bg.set_corner_radius_all(6)
	var bar_fill := StyleBoxFlat.new()
	bar_fill.bg_color = TEAL if trust >= 40 else RED
	bar_fill.set_corner_radius_all(6)
	trust_bar.add_theme_stylebox_override("background", bar_bg)
	trust_bar.add_theme_stylebox_override("fill", bar_fill)
	inside.add_child(trust_bar)
	var start := _button("BÖLÜME GİR", true)
	start.custom_minimum_size.y = 54
	start.pressed.connect(_show_case)
	inside.add_child(start)


func _show_case(reset_clock: bool = true) -> void:
	var preserved_time := remaining_seconds
	if is_instance_valid(case_timer):
		case_timer.stop()
	var passenger: Dictionary = _current_case()
	var case_id := _current_case_id()
	var chapter := clampi(int(current_passenger / 10) + 1, 1, 10)
	if is_instance_valid(backdrop):
		backdrop.set_chapter(chapter)
	if is_instance_valid(ambience_player):
		ambience_player.set_chapter(chapter)
	var column := _make_screen()
	var header := HBoxContainer.new()
	column.add_child(header)
	var brand := _label("SON SEFER     /     GECE VARDİYASI", 14, GOLD)
	brand.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(brand)
	var progress := _label("VARDİYA %03d / %03d     •     PUAN %d     •     GÜVEN %d     •     İZ %d/10" % [current_passenger + 1, PASSENGERS.size(), score, trust, story_evidence.size()], 14, CREAM, HORIZONTAL_ALIGNMENT_RIGHT)
	header.add_child(progress)
	timer_label = _label("", 14, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	header.add_child(timer_label)
	var board_button := _button("KANIT PANOSU", false)
	board_button.pressed.connect(_open_evidence_board)
	header.add_child(board_button)
	var notebook_button := _button("DEFTER", false)
	notebook_button.pressed.connect(_open_notebook.bind("case"))
	header.add_child(notebook_button)
	var menu_button := _button("MENÜ", false)
	menu_button.pressed.connect(_show_title)
	header.add_child(menu_button)
	var rule := ColorRect.new()
	rule.color = Color(0.91, 0.75, 0.46, 0.35)
	rule.custom_minimum_size.y = 1
	column.add_child(rule)
	column.add_child(_label("BÖLÜM %02d  •  %s" % [chapter, CHAPTER_TITLES[chapter - 1]], 17, TEAL))
	column.add_child(_label(CHAPTER_LINES[chapter - 1], 13, MUTED))

	var content := HBoxContainer.new()
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 18)
	column.add_child(content)

	var portrait_panel := _panel(PANEL, 320)
	portrait_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(portrait_panel)
	var portrait_box := _margin_inside(portrait_panel, 18)
	var portrait := TravellerPortrait.new()
	portrait.custom_minimum_size = Vector2(250, 245)
	portrait.size_flags_vertical = Control.SIZE_EXPAND_FILL
	portrait.person_index = case_id
	portrait.skin = passenger["portrait"]
	portrait.coat = passenger["coat"]
	portrait_box.add_child(portrait)
	var person_name := _label(passenger["name"], 25, CREAM, HORIZONTAL_ALIGNMENT_CENTER)
	portrait_box.add_child(person_name)
	var role := _label(passenger["role"], 14, TEAL, HORIZONTAL_ALIGNMENT_CENTER)
	portrait_box.add_child(role)
	var route := _label(passenger["route"], 12, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	portrait_box.add_child(route)

	var dossier := _panel(PANEL, 0)
	dossier.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dossier.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(dossier)
	var details := _margin_inside(dossier, 20)
	var details_margin := details.get_parent() as MarginContainer
	details_margin.remove_child(details)
	var detail_scroll := ScrollContainer.new()
	detail_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detail_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	detail_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	details_margin.add_child(detail_scroll)
	detail_scroll.add_child(details)
	details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	details.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var dossier_title := _label("%s     /     DOSYA %03d" % [passenger.get("difficulty", "VARDİYA"), passenger.get("number", current_passenger + 1)], 14, GOLD)
	details.add_child(dossier_title)
	var case_question := _label(passenger.get("case_question", "Yolcunun anlattıkları dosyadaki kayıtlarla tutarlı mı?"), 18, TEAL)
	case_question.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	details.add_child(case_question)
	var dialogue_text: String = passenger["dialogue"]
	var memory := _last_decision_for(passenger["name"])
	if not memory.is_empty():
		var memory_line: String
		if memory["accepted"] and memory["correct"]:
			memory_line = "Geçen vardiyada bana güvendin. Bugün de dosyamı dikkatle incele."
		elif memory["accepted"]:
			memory_line = "Geçen vardiyada beni içeri aldın ama kararın başkalarını zor durumda bıraktı."
		elif memory["correct"]:
			memory_line = "Geçen sefer beni geri çevirdin. Zordu ama ipuçlarını doğru okumuştun."
		else:
			memory_line = "Geçen vardiyada beni geri çevirdin. Bu kez lütfen bütün kayıtları dinle."
		dialogue_text += "\n\n%s" % memory_line
	if passenger.get("returning", false) and memory.is_empty():
		dialogue_text += "\n\nBir yerden tanışıyoruz sanki..."
	if trust >= 75:
		dialogue_text += "\n\nİskele halkı kararlarına güveniyor."
	elif trust <= 25:
		dialogue_text += "\n\nİskelede sana güvenenlerin sayısı azaldı."
	var dialogue := _label("“%s”" % dialogue_text, 21, CREAM)
	dialogue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	details.add_child(dialogue)
	var ticket := _button("BİLET / KAYIT     •     %s" % passenger["ticket"], inspected.has(TICKET_INSPECT_ID))
	ticket.alignment = HORIZONTAL_ALIGNMENT_LEFT
	ticket.custom_minimum_size.y = 50
	ticket.pressed.connect(_toggle_clue.bind(TICKET_INSPECT_ID))
	details.add_child(ticket)
	if inspected.has(TICKET_INSPECT_ID):
		var ticket_note := _label("↳  %s" % passenger["ticket"], 15, GOLD)
		ticket_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		details.add_child(ticket_note)

	var clue_row := VBoxContainer.new()
	clue_row.add_theme_constant_override("separation", 8)
	details.add_child(clue_row)
	for i in range(passenger["clues"].size()):
		var clue: Dictionary = passenger["clues"][i]
		var clue_button := _button("İPUCU 0%d  •  %s" % [i + 1, clue["title"]], inspected.has(i))
		clue_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		clue_button.custom_minimum_size.y = 44
		clue_button.pressed.connect(_toggle_clue.bind(i))
		clue_row.add_child(clue_button)
		if inspected.has(i):
			var is_story_clue: bool = not String(passenger.get("fragment", "")).is_empty() and i == passenger["clues"].size() - 1
			var clue_note := _label("↳  %s" % clue["body"], 15, GOLD if is_story_clue else MUTED)
			clue_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			details.add_child(clue_note)
			if is_story_clue and story_evidence.has(passenger["fragment"]):
				details.add_child(_label("✦ İSKELE DEFTERİNE EKLENDİ", 13, GOLD))
	if solved_evidence_cases.has(case_id):
		details.add_child(_label("✓ KANIT PANOSUNDA BAĞLANTI KURULDU", 14, TEAL))

	var question_heading := _label("BİR EK SORU SOR     •     İSTEĞE BAĞLI, TEK HAK", 14, TEAL)
	details.add_child(question_heading)
	if asked_question < 0:
		var question_row := HBoxContainer.new()
		question_row.add_theme_constant_override("separation", 8)
		details.add_child(question_row)
		for i in range(passenger["questions"].size()):
			var question: Dictionary = passenger["questions"][i]
			var q_button := _button(question["q"], false)
			q_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			q_button.custom_minimum_size.y = 42
			q_button.pressed.connect(_ask_question.bind(i))
			question_row.add_child(q_button)
	else:
		var answer: Dictionary = passenger["questions"][asked_question]
		var answer_label := _label("SEN:  %s\n\n%s:  %s" % [answer["q"], passenger["name"].to_upper(), answer["a"]], 16, CREAM)
		answer_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		details.add_child(answer_label)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.add_child(spacer)
	var decisions := HBoxContainer.new()
	decisions.add_theme_constant_override("separation", 12)
	details.add_child(decisions)
	var reject := _button("GERİ ÇEVİR", false)
	reject.custom_minimum_size.y = 52
	reject.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	reject.pressed.connect(_resolve_case.bind(false))
	decisions.add_child(reject)
	var board := _button("VAPURA AL", true)
	board.custom_minimum_size.y = 52
	board.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	board.pressed.connect(_resolve_case.bind(true))
	decisions.add_child(board)

	var footer := _label("İPUCU: AD, TARİH, SAAT VE KAYIT NUMARALARINI BİRBİRİYLE KARŞILAŞTIR", 13, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(footer)
	_start_case_clock(reset_clock, preserved_time)


func _toggle_clue(clue_index: int) -> void:
	if inspected.has(clue_index):
		inspected.erase(clue_index)
	else:
		inspected[clue_index] = true
		var passenger: Dictionary = _current_case()
		if clue_index >= 0 and clue_index == passenger["clues"].size() - 1:
			var fragment: String = passenger.get("fragment", "")
			if not fragment.is_empty() and not story_evidence.has(fragment):
				story_evidence.append(fragment)
				settings.set_value("progress", "story_evidence", story_evidence)
				settings.save("user://son_sefer.cfg")
	_show_case(false)


func _ask_question(question_index: int) -> void:
	asked_question = question_index
	_show_case(false)


func _resolve_case(accepted: bool, timed_out: bool = false) -> void:
	if is_instance_valid(case_timer):
		case_timer.stop()
	var passenger: Dictionary = _current_case()
	var correct: bool = accepted == passenger["allow"]
	if timed_out:
		correct = false
	var point_change := -15 if timed_out else (20 if correct else -10)
	score += point_change
	trust = clampi(trust + (2 if correct else (-4 if timed_out else -3)), 0, 100)
	correct_streak = correct_streak + 1 if correct else 0
	var fragment: String = passenger.get("fragment", "")
	var fragment_found := not fragment.is_empty() and story_evidence.has(fragment)
	decision_history.append({
		"case_number": int(passenger.get("number", current_passenger + 1)),
		"chapter": int(current_passenger / 10) + 1,
		"name": passenger["name"],
		"accepted": accepted,
		"timed_out": timed_out,
		"correct": correct,
		"point_change": point_change,
		"trust_change": 2 if correct else (-4 if timed_out else -3),
		"explanation": passenger.get("case_note", ""),
		"fragment_found": fragment_found
	})
	_unlock_achievement("FIRST_DUTY")
	if correct_streak >= 10:
		_unlock_achievement("STEADY_HAND")
	_save_progress(current_passenger + 1, _time_limit())
	_show_result(correct, accepted, timed_out)


func _show_result(correct: bool, accepted: bool, timed_out: bool = false) -> void:
	var passenger: Dictionary = _current_case()
	var column := _make_screen()
	var header := HBoxContainer.new()
	column.add_child(header)
	var header_text := _label("SON SEFER     /     KARARIN", 15, GOLD)
	header_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(header_text)
	header.add_child(_label("PUAN  %d / 2000" % score, 15, CREAM, HORIZONTAL_ALIGNMENT_RIGHT))
	var title := _label("SÜRE DOLDU" if timed_out else ("DOĞRU KARAR" if correct else "YANLIŞ KARAR"), 34, RED if timed_out else (TEAL if correct else RED), HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(title)
	var card := _panel(PANEL, 0)
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(card)
	var inner := _margin_inside(card, 16)
	var decision := "Karar vermeye yetişemedin; yolcu vapura alınmadı." if timed_out else ("Vapura aldın." if accepted else "Vapura almadın.")
	var why: String = passenger.get("case_note", "Belgelerdeki ayrıntıları karşılaştırıp kararını verdin.")
	var lost_points := 15 if timed_out else (20 if correct else 10)
	var copy := _label("%s  •  %s\n%s   %s%d PUAN" % [passenger["name"], decision, why, "+" if correct else "−", lost_points], 17, CREAM, HORIZONTAL_ALIGNMENT_CENTER)
	copy.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inner.add_child(copy)
	var fragment: String = passenger.get("fragment", "")
	if not fragment.is_empty() and story_evidence.has(fragment):
		inner.add_child(_label("✦ YIRTIK NÖBET SAYFASI DEFTERE EKLENDİ  •  %d / 10" % story_evidence.size(), 14, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	var journey := BoardingAnimation.new()
	journey.custom_minimum_size = Vector2(720, 260)
	journey.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	journey.size_flags_vertical = Control.SIZE_EXPAND_FILL
	journey.skin = passenger["portrait"]
	journey.coat = passenger["coat"]
	journey.person_index = _current_case_id()
	inner.add_child(journey)
	var movement := _label("VAPURA YÜRÜYOR..." if accepted else "ÖFKELİ ADIMLARLA UZAKLAŞIYOR...", 15, GOLD if accepted else RED, HORIZONTAL_ALIGNMENT_CENTER)
	inner.add_child(movement)
	var next := _button("SONRAKİ DOSYA", true)
	next.custom_minimum_size.y = 52
	next.visible = false
	next.pressed.connect(_next_passenger)
	inner.add_child(next)
	journey.completed.connect(func():
		movement.text = "YOLCU VAPURA BİNDİ" if accepted else "YOLCU İSKELEDEN AYRILDI"
		next.visible = true
	)
	journey.play(accepted)


func _next_passenger() -> void:
	current_passenger += 1
	inspected.clear()
	asked_question = -1
	selected_evidence.clear()
	evidence_board_feedback = ""
	if current_passenger == 10:
		_unlock_achievement("CHAPTER_ONE")
	if current_passenger >= PASSENGERS.size():
		_unlock_achievement("LAST_PASSENGER")
		_show_ending()
	elif current_passenger % 10 == 0:
		_show_chapter_intro()
	else:
		_show_case()


func _time_limit() -> int:
	return 0 if difficulty_mode == 0 else (90 if difficulty_mode == 1 else 45)


func _start_case_clock(reset_clock: bool, preserved_time: int) -> void:
	if not is_instance_valid(case_timer):
		return
	case_timer.stop()
	var limit := _time_limit()
	if limit == 0:
		remaining_seconds = 0
		if is_instance_valid(timer_label):
			timer_label.text = "SÜRESİZ"
			timer_label.add_theme_color_override("font_color", TEAL)
		return
	if reset_clock or preserved_time <= 0:
		remaining_seconds = limit
	else:
		remaining_seconds = mini(preserved_time, limit)
	if is_instance_valid(timer_label):
		timer_label.text = "%02d:%02d" % [int(remaining_seconds / 60), remaining_seconds % 60]
		timer_label.add_theme_color_override("font_color", GOLD if remaining_seconds > 15 else RED)
	case_timer.start()


func _tick_case_timer() -> void:
	remaining_seconds -= 1
	if is_instance_valid(timer_label):
		timer_label.text = "%02d:%02d" % [int(maxi(remaining_seconds, 0) / 60), maxi(remaining_seconds, 0) % 60]
		timer_label.add_theme_color_override("font_color", GOLD if remaining_seconds > 15 else RED)
	if remaining_seconds <= 0:
		_resolve_case(false, true)
	else:
		settings.set_value("progress", "remaining_seconds", remaining_seconds)
		settings.save("user://son_sefer.cfg")


func _pause_case_clock() -> void:
	if is_instance_valid(case_timer):
		case_timer.stop()
	if current_passenger < PASSENGERS.size() and not decision_history.is_empty():
		_save_progress(current_passenger, remaining_seconds)


func _save_progress(case_position: int, seconds: int) -> void:
	settings.set_value("progress", "case_index", case_position)
	settings.set_value("progress", "score", score)
	settings.set_value("progress", "trust", trust)
	settings.set_value("progress", "history", decision_history)
	settings.set_value("progress", "story_evidence", story_evidence)
	settings.set_value("progress", "case_order", case_order)
	settings.set_value("progress", "solved_evidence_cases", solved_evidence_cases)
	settings.set_value("progress", "remaining_seconds", seconds)
	settings.set_value("progress", "correct_streak", correct_streak)
	settings.save("user://son_sefer.cfg")


func _open_evidence_board() -> void:
	_pause_case_clock()
	_show_evidence_board()


func _show_evidence_board() -> void:
	var passenger := _current_case()
	var column := _make_screen()
	var header := HBoxContainer.new()
	column.add_child(header)
	var title := _label("KANIT PANOSU", 30, CREAM)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	header.add_child(_label("2 İPUCU SEÇ  •  DOSYA %03d" % int(passenger.get("number", current_passenger + 1)), 14, GOLD, HORIZONTAL_ALIGNMENT_RIGHT))
	var card := _panel(PANEL, 0)
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(card)
	var inside := _margin_inside(card, 18)
	inside.add_child(_label("Bilet ve ipuçlarından ikisini seç; ardından dosyanın tutarlı olup olmadığına karar ver.", 16, MUTED))
	var ticket_button := _button("BİLET / KAYIT   •   %s" % passenger["ticket"], selected_evidence.has(TICKET_INSPECT_ID))
	ticket_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	ticket_button.custom_minimum_size.y = 50
	ticket_button.pressed.connect(_select_evidence.bind(TICKET_INSPECT_ID))
	inside.add_child(ticket_button)
	var clues: Array = passenger["clues"]
	for i in range(clues.size()):
		var clue: Dictionary = clues[i]
		var button := _button("İPUCU %02d  •  %s" % [i + 1, clue["title"]], selected_evidence.has(i))
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.custom_minimum_size.y = 46
		button.pressed.connect(_select_evidence.bind(i))
		inside.add_child(button)
	var chosen_text := "SEÇİLEN: "
	for evidence_id in selected_evidence:
		chosen_text += ("BİLET" if evidence_id == -1 else String(clues[evidence_id]["title"])) + "   •   "
	inside.add_child(_label(chosen_text if selected_evidence.size() > 0 else "SEÇİLEN: Henüz kanıt seçilmedi", 15, TEAL))
	if not evidence_board_feedback.is_empty():
		var feedback := _label(evidence_board_feedback, 15, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
		feedback.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		inside.add_child(feedback)
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 10)
	inside.add_child(actions)
	var consistent := _button("TUTARLI", true)
	consistent.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	consistent.pressed.connect(_submit_inference.bind(true))
	actions.add_child(consistent)
	var conflict := _button("ÇELİŞKİ VAR", false)
	conflict.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	conflict.pressed.connect(_submit_inference.bind(false))
	actions.add_child(conflict)
	var back := _button("DOSYAYA DÖN", false)
	back.custom_minimum_size.y = 48
	back.pressed.connect(func(): _show_case(false))
	column.add_child(back)


func _select_evidence(evidence_id: int) -> void:
	if selected_evidence.has(evidence_id):
		selected_evidence.erase(evidence_id)
	elif selected_evidence.size() < 2:
		selected_evidence.append(evidence_id)
	else:
		evidence_board_feedback = "İki kanıt seçili. Önce birini kaldır."
	_show_evidence_board()


func _submit_inference(consistent: bool) -> void:
	if selected_evidence.size() != 2:
		evidence_board_feedback = "Çıkarım için tam iki kanıt seçmelisin."
		_show_evidence_board()
		return
	var passenger := _current_case()
	var expected: Array = passenger.get("key_clues", [-1, 0])
	var chosen := selected_evidence.duplicate()
	chosen.sort()
	var expected_sorted: Array = expected.duplicate()
	expected_sorted.sort()
	if chosen != expected_sorted:
		evidence_board_feedback = "Bu ikili dosyanın belirleyici kanıtlarını bağlamıyor. Başka ipuçlarını karşılaştır."
	else:
		var correct_inference := consistent == bool(passenger["allow"])
		if correct_inference:
			var case_id := _current_case_id()
			if not solved_evidence_cases.has(case_id):
				solved_evidence_cases.append(case_id)
				trust = clampi(trust + 1, 0, 100)
				if solved_evidence_cases.size() >= 10:
					_unlock_achievement("SHARP_EYE")
				_save_progress(current_passenger, remaining_seconds)
			evidence_board_feedback = "Doğru bağlantı. %s" % passenger.get("case_note", "İki kanıt birbiriyle örtüşüyor.")
		else:
			evidence_board_feedback = "Kanıtları doğru buldun; ancak bunların söylediği sonucu ters yorumladın."
	_show_evidence_board()


func _last_decision_for(passenger_name: String) -> Dictionary:
	for i in range(decision_history.size() - 1, -1, -1):
		var record: Dictionary = decision_history[i]
		if record.get("name", "") == passenger_name:
			return record
	return {}


func _open_notebook(return_view: String) -> void:
	notebook_return_view = return_view
	_show_notebook()


func _show_notebook() -> void:
	_pause_case_clock()
	var column := _make_screen()
	var header := HBoxContainer.new()
	column.add_child(header)
	var heading := _label("VARDİYA DEFTERİ", 30, CREAM)
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(heading)
	header.add_child(_label("İSKELE GÜVENİ  %d / 100" % trust, 16, TEAL, HORIZONTAL_ALIGNMENT_RIGHT))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(scroll)
	var entries := VBoxContainer.new()
	entries.add_theme_constant_override("separation", 8)
	scroll.add_child(entries)
	entries.add_child(_label("NİHAT'IN NÖBET DEFTERİ   •   %d / 10 SAYFA" % story_evidence.size(), 18, GOLD))
	if story_evidence.is_empty():
		entries.add_child(_label("Her bölümün son dosyasında yırtık bir kayıt saklı. İncelediğin sayfalar burada birikir.", 14, MUTED))
	else:
		for fragment in story_evidence:
			var fragment_panel := _panel(Color("#10253a"), 0)
			fragment_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			entries.add_child(fragment_panel)
			var fragment_inner := _margin_inside(fragment_panel, 10)
			var fragment_text := _label("✦  %s" % fragment, 14, CREAM)
			fragment_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			fragment_inner.add_child(fragment_text)
	if decision_history.is_empty():
		entries.add_child(_label("Henüz karar kaydedilmedi. İlk dosyayı tamamlayınca vardiya defteri burada görünür.", 18, MUTED))
	else:
		for chapter_index in range(1, 11):
			var chapter_records: Array[Dictionary] = []
			for record_variant in decision_history:
				var record: Dictionary = record_variant
				if int(record.get("chapter", 1)) == chapter_index:
					chapter_records.append(record)
			if chapter_records.is_empty():
				continue
			entries.add_child(_label("BÖLÜM %02d  •  %s" % [chapter_index, CHAPTER_TITLES[chapter_index - 1]], 18, GOLD))
			for record in chapter_records:
				var action := "VAPURA AL" if record["accepted"] else "GERİ ÇEVİR"
				var verdict := "DOĞRU" if record["correct"] else "YANLIŞ"
				var tint := TEAL if record["correct"] else RED
				var row := _panel(Color("#10253a"), 0)
				row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				entries.add_child(row)
				var row_inner := _margin_inside(row, 10)
				var line := _label("DOSYA %03d   •   %s   •   %s   •   %s%d PUAN" % [int(record["case_number"]), record["name"], action, verdict, int(record["point_change"])], 15, tint)
				row_inner.add_child(line)
				var trust_sign := "+" if int(record.get("trust_change", 0)) >= 0 else ""
				var explanation := _label("GÜVEN %s%d   •   %s" % [trust_sign, int(record.get("trust_change", 0)), record.get("explanation", "")], 14, MUTED)
				explanation.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
				row_inner.add_child(explanation)
	var back := _button("VARDİYAYA DÖN", true)
	back.custom_minimum_size.y = 50
	back.pressed.connect(_return_from_notebook)
	column.add_child(back)


func _return_from_notebook() -> void:
	match notebook_return_view:
		"case":
			_show_case(false)
		"ending":
			_show_ending()
		_:
			_show_title()


func _show_ending() -> void:
	_pause_case_clock()
	var column := _make_screen()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	var eyebrow := _label("GÜN DOĞUYOR     •     VARDİYA TAMAMLANDI", 12, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(eyebrow)
	var correct_count := 0
	for record in decision_history:
		if record["correct"]:
			correct_count += 1
	var mystery_solved := story_evidence.size() >= 10
	var ending_title: String
	if mystery_solved and score >= 1400 and trust >= 70:
		ending_title = "NİHAT'IN İTİRAFI"
	elif mystery_solved:
		ending_title = "SİSİN ARDINDAKİ GERÇEK"
	elif score >= 1400 and trust >= 70:
		ending_title = "İSKELEDE HUZUR"
	elif score >= 1400:
		ending_title = "SUSKUN VARDİYA"
	elif trust >= 65:
		ending_title = "YOLCULARIN TERCİHİ"
	elif score >= 800:
		ending_title = "SABAHIN İLK IŞIKLARI"
	else:
		ending_title = "KAÇAN SON VAPUR"
	if not endings_seen.has(ending_title):
		endings_seen.append(ending_title)
		settings.set_value("meta", "endings_seen", endings_seen)
		settings.save("user://son_sefer.cfg")
	if mystery_solved:
		_unlock_achievement("NIGHT_WATCH")
	if endings_seen.size() >= 7:
		_unlock_achievement("ALL_ENDINGS")
	_save_progress(PASSENGERS.size(), 0)
	var ending_color := TEAL if score >= 1400 and trust >= 70 else (GOLD if score >= 800 or trust >= 65 or mystery_solved else RED)
	var title := _label(ending_title, 38, ending_color, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(title)
	var card := _panel(PANEL, 680)
	card.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	column.add_child(card)
	var inner := _margin_inside(card, 24)
	var summary := "Yüz yolcunun dosyasını tamamladın.\n\nDoğru karar: %d / 100\nVardiya puanı: %d / 2000\nİskele güveni: %d / 100\nNöbet defteri: %d / 10 sayfa\nFarklı görülen final: %d / 7\n\n" % [correct_count, score, trust, story_evidence.size(), endings_seen.size()]
	if mystery_solved:
		summary += "Nihat, saati kurtarma işareti beklensin diye değiştirmiş; iskeledeki insanlar onun nedenini şimdi biliyor. "
	if score >= 1400 and trust >= 70:
		summary += "İskeleden geçenler doğru yere ulaştı. Eski yolcular da kararlarına güveniyor; gün doğarken iskele seni kendi insanı sayıyor."
	elif score >= 1400:
		summary += "Dosyaları çoğunlukla doğru çözdün, ancak iskele halkı sana yaklaşmakta hâlâ temkinli."
	elif trust >= 65:
		summary += "Yolcular sana güveniyor ve birbirine yardım ediyor. Yine de birkaç çelişki gözünden kaçtı; son vapur sisin içinde kayboldu."
	elif score >= 800:
		summary += "Bazı kararların işe yaradı, bazıları aklında kaldı. Bu gece sana şunu öğretti: ayrıntılar önemlidir."
	else:
		summary += "Vardiya beklediğinden zor geçti. İskeleden kimlerin geçtiğini yeniden düşünmek için bir gece daha isteyebilirsin."
	var text := _label(summary, 18, CREAM, HORIZONTAL_ALIGNMENT_CENTER)
	text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inner.add_child(text)
	var replay := _button("YENİDEN OYNA", true)
	replay.custom_minimum_size.y = 54
	replay.pressed.connect(_begin_shift)
	inner.add_child(replay)
	var notebook := _button("VARDİYA DEFTERİNİ İNCELE", false)
	notebook.pressed.connect(_open_notebook.bind("ending"))
	inner.add_child(notebook)
	var menu := _button("ANA MENÜ", false)
	menu.pressed.connect(_show_title)
	inner.add_child(menu)


func _label(text: String, font_size: int, color: Color, alignment: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var result := Label.new()
	result.text = text
	result.horizontal_alignment = alignment
	result.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	result.add_theme_font_size_override("font_size", int(round(float(font_size) * text_scale)))
	result.add_theme_color_override("font_color", Color.WHITE if high_contrast and color == MUTED else color)
	return result


func _button(text: String, primary: bool) -> Button:
	var result := Button.new()
	result.text = text
	result.focus_mode = Control.FOCUS_ALL
	result.add_theme_font_size_override("font_size", int(round(14.0 * text_scale)))
	result.add_theme_color_override("font_color", INK if primary else CREAM)
	result.add_theme_color_override("font_hover_color", INK if primary else GOLD)
	result.add_theme_color_override("font_pressed_color", INK)
	result.add_theme_stylebox_override("normal", _button_style(primary, false))
	result.add_theme_stylebox_override("hover", _button_style(primary, true))
	result.add_theme_stylebox_override("pressed", _button_style(primary, true))
	result.add_theme_stylebox_override("focus", _button_style(primary, true))
	result.add_theme_stylebox_override("disabled", _button_style(primary, false))
	return result


func _button_style(primary: bool, hovered: bool) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = GOLD if primary else (Color("#203b50") if hovered else Color("#172e43"))
	if primary and hovered:
		style.bg_color = Color("#ffda91")
	style.border_color = Color.WHITE if high_contrast else (Color("#f7dea8") if primary else Color("#34536a"))
	style.set_border_width_all(2 if high_contrast else 1)
	style.set_corner_radius_all(7)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style


func _panel(color: Color, min_width: float) -> PanelContainer:
	var result := PanelContainer.new()
	result.custom_minimum_size.x = min_width
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color.WHITE if high_contrast else Color(0.62, 0.72, 0.75, 0.35)
	style.set_border_width_all(2 if high_contrast else 1)
	style.set_corner_radius_all(12)
	style.shadow_color = Color(0, 0, 0, 0.18)
	style.shadow_size = 12
	result.add_theme_stylebox_override("panel", style)
	return result


func _margin_inside(parent: Control, amount: int) -> VBoxContainer:
	var margins := MarginContainer.new()
	margins.add_theme_constant_override("margin_left", amount)
	margins.add_theme_constant_override("margin_right", amount)
	margins.add_theme_constant_override("margin_top", amount)
	margins.add_theme_constant_override("margin_bottom", amount)
	parent.add_child(margins)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	margins.add_child(column)
	return column
