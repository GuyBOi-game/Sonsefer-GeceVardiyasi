# Son Sefer: Gece Vardiyası

Son vapur kalkmadan önce iskeledeki yolcuların dosyalarını incele. Biletleri, ifadeleri ve küçük ayrıntıları karşılaştır; kimi vapura alacağına sen karar ver.

Bu, gece atmosferinde geçen, tek oyunculu bir hikâye ve çıkarım oyunudur. Her vardiyada dosyaların sırası değişir. Geri dönen yolcular önceki kararlarını hatırlar; güvenin ve nöbet defterinde bulduğun sayfalar sabahı ve finali etkiler.

## Özellikler
- 100 yolcu dosyası, 10 bölüm ve farklı vaka türleri
- Biletler ile ipuçlarını eşleştirdiğin kanıt panosu
- Rahat, Normal ve Zor vardiya seçenekleri
- Önceki seçimleri hatırlayan yolcular ve 7 farklı final
- Yerel başarımlar, vardiya defteri ve otomatik kayıt
- Kodla çizilmiş yağmur, sis, iskele ve yolcu animasyonları

## Oynanış
Her dosyada kayıtları incele, istersen bir ek soru sor ve yolcuyu vapura alıp almayacağına karar ver. Dosyaları çözmek için isim, tarih, güzergâh, saat ve kayıt numaralarını karşılaştır.

## Kontroller
Fare ile menüleri, dosyaları ve kanıt panosunu kullan.

## Durum
Bu, ilk oynanabilir Windows sürümüdür. Geri bildirime açığım.

## Diller
Arayüz ve hikâye: Türkçe. Steam başarımları bu itch.io yapısında kapalıdır; oyun içi başarımlar yerel olarak çalışır.
