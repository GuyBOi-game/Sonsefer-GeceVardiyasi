extends RefCounted

const FIRST_NAMES := ["Ece", "Mert", "Derya", "Onur", "Elif", "Bora", "Selma", "Kaan", "Aylin", "Emre", "Seda", "Umut", "Nihan", "Arda", "Ceren", "Baran", "İpek", "Deniz", "Ozan", "Pelin"]
const LAST_NAMES := ["Yalçın", "Özdemir", "Korkmaz", "Şahin", "Aydın", "Koç", "Ergin", "Tekin", "Aslan", "Güneş", "Çetin", "Akın", "Vural", "Kaya", "Eren", "Polat", "Arslan", "Yıldız", "Demir", "Sönmez"]
const ROLES := ["Restoratör", "Eczacı", "Müzisyen", "Kütüphaneci", "Teknisyen", "Aşçı", "Haritacı", "Çiçekçi", "Fotoğrafçı", "Öğretmen"]
const DESTINATIONS := ["Karaköy", "Eminönü", "Üsküdar", "Beşiktaş", "Kadıköy"]
const COATS := ["#607d82", "#9b6d71", "#697b9a", "#8a795f", "#567c72", "#8a687f", "#657e92", "#a16f52", "#687d66", "#7c6b8e"]
const THREAD_CLUES := [
	"Yırtılmış çizelgede 03.30 saatinin altına altın kalemle N.K. baş harfleri atılmış.",
	"Yağmurda akmış notta 'saate değil, fenerin ışığına bak' yazıyor. Not N.K. imzalı.",
	"Bakım fişine göre iskele saati Nihat Korkut tarafından on iki dakika ileri alınmış.",
	"Mühürlü bir kayıtta, uyarı çanından sonra kıyıda bekleyen bir çocuk ve sağlık görevlisi görünüyor.",
	"Eski nöbet defteri son vapur için tek boş koltuk ayırmış: 'üçüncü fener işaretine kadar bekle.'",
	"Sinyal defterinde üç kısa ışık 'BEKLE — kıyıda biri var' olarak açıklanmış.",
	"Yırtık sayfa, Nihat'ın kurtarma ekibi çocuğu getirebilsin diye vapuru geciktirdiğini söylüyor.",
	"Birbirini tanımayan iki yolcu aynı sisli gecede üç fener işareti gördüğünü anlatıyor.",
	"Pirinç anahtar eski sinyal odasının dolabını açıyor. İçeride Nihat'ın imzalı ifadesi var.",
	"Nihat'ın son notu: 'Kurtarma işareti gelene dek ekip beklesin diye saati değiştirdim. Nedenini kayda geçirmeliydim.'"
]
const RED_HERRINGS := [
	"İskele saati iki dakika geri kalıyor; çizelgedeki sefer saati yine de resmi kaynaktır.",
	"İmza biçimi kişiden kişiye değişir. Bu dosyada resmi isim satırını esas al.",
	"Haritada benzer adlı iki durak var. Renkli aktarma çizgisi, biletteki varış iskelesini değiştirmez.",
	"Kutu mührü eski olabilir; manifestodaki eşya türü ve adedi ayrıca kontrol et.",
	"Cep takviminde bir önceki güne ait not var. Kartın tarih satırıyla karşılaştırmadan hüküm verme.",
	"Eski personel üniforması hâlâ giyilebilir. Yetki için vardiya listesi ve isim eşleşmesi gerekir.",
	"Fişin yırtık köşesi teslim edildiğini kanıtlamaz; kayıt numarası daha belirleyici.",
	"Yolcu kestirme bir yol bildiğini söylüyor. Tarifedeki kalkış ve yanaşma saatleri değişmiyor.",
	"Davetli listesindeki bazı soyadları baş harfle kısaltılmış. Karttaki tam isim ve tarih önemli.",
	"Aynı sefer kodu her gece kullanılıyor. Tarih damgasını okumadan karar verme."
]


static func make_cases(start_at: int, amount: int, returning_people: Array[Dictionary] = []) -> Array[Dictionary]:
	var results: Array[Dictionary] = []
	var rng := RandomNumberGenerator.new()
	rng.seed = 904113
	for index in range(start_at, start_at + amount):
		var pattern := index % 10
		var variant := int(index / 10)
		var first: String = FIRST_NAMES[index % FIRST_NAMES.size()]
		var last_index := (variant * 7 + (index % 20) * 3) % LAST_NAMES.size()
		var full_name: String = first + " " + LAST_NAMES[last_index]
		var role: String = ROLES[(index + variant) % ROLES.size()]
		var returning := index >= 10 and index % 10 == 0 and not returning_people.is_empty()
		if returning:
			var familiar: Dictionary = returning_people[int(index / 10 - 1) % returning_people.size()]
			full_name = familiar["name"]
			role = familiar["role"]
		var destination: String = DESTINATIONS[(index * 3 + variant) % DESTINATIONS.size()]
		var allowed := rng.randi_range(0, 99) >= 39
		var pack := _make_puzzle(pattern, variant, full_name, role, destination, allowed, index)
		pack["name"] = full_name
		pack["role"] = role
		pack["route"] = "Kadıköy → %s" % destination
		pack["portrait"] = Color("#bd8f73") if index % 2 == 0 else Color("#d2a184")
		pack["coat"] = Color(COATS[index % COATS.size()])
		pack["allow"] = allowed
		pack["difficulty"] = "USTALIK %d" % (int(index / 20) + 1)
		pack["difficulty_level"] = int(index / 20) + 1
		pack["number"] = index + 1
		pack["chapter"] = int(index / 10) + 1
		pack["returning"] = returning
		results.append(pack)
	return results


static func _make_puzzle(pattern: int, variant: int, full_name: String, role: String, destination: String, allowed: bool, index: int) -> Dictionary:
	var suffix: String = ["eski taş köprü", "mavi depo", "saat kulesi", "kapalı çarşı", "kıyı atölyesi", "tünel çıkışı", "fener sokağı", "yük iskelesi", "kış bahçesi", "eski postane"][variant % 10]
	var ticket := ""
	var dialogue := ""
	var solution := ""
	var clues: Array[Dictionary] = []
	var questions: Array[Dictionary] = []
	match pattern:
		0:
			var claimed_time := "03.30"
			var printed_time := claimed_time if allowed else "02.50"
			dialogue = "%s tarafındaki %s için son seferi kullanacağım. Biletimi bu gece için aldım." % [destination, suffix]
			ticket = "Basılı sefer saati %s. Biletin tarihi bu gece." % printed_time
			clues = [
				{"title": "Sefer çizelgesi", "body": "İskele panosunda %s seferi 03.30 olarak kayıtlı. Biletteki saatle karşılaştır." % destination},
				{"title": "Peron damgası", "body": "Damga bu gece 03.30'dan hemen önce vurulmuş. Mürekkep hâlâ taze; tarih satırını da kontrol et."},
				{"title": "Yolcu notu", "body": "%s'nin arkasında 'ilk ışıkta aç' yazıyor. Bu not tek başına sefer saatini kanıtlamıyor." % suffix}
			]
			questions = _questions("sefer saati", "peron damgası", "notun kime ait olduğu", "Çizelgeyi gördüm, 03.30'da kalkıyormuş.", "Saat eski olabilir; ben bu geceye göre aldım.", "Not bana iş yerinden verildi.")
			solution = "Bilette %s yazıyor; iskele çizelgesi bu geceki kalkışı 03.30 gösteriyor. Tarih damgası da bu geceye ait." % ("03.30" if allowed else "02.50")
		1:
			var ticket_name: String = full_name if allowed else FIRST_NAMES[(index + 9) % FIRST_NAMES.size()] + " " + LAST_NAMES[(index + 4) % LAST_NAMES.size()]
			dialogue = "Kimliğim yanımda. %s'deki %s'ye gidiyorum; bilette adımın yazdığından eminim." % [destination, suffix]
			ticket = "Bilet üzerindeki yolcu adı: %s." % ticket_name
			clues = [
				{"title": "Fotoğraflı kimlik", "body": "%s adına düzenlenmiş; fotoğraf yolcuyla eşleşiyor. Biletteki isimle harf harf karşılaştır." % full_name},
				{"title": "Rezervasyon fişi", "body": "Fişte koltuk 14B ve aynı sefer kodu var. İsim satırındaki soyadı küçük yazılmış."},
				{"title": "İmza", "body": "İki belgede de imza bulunuyor; biçimleri benzer, fakat bu tek başına isim eşleşmesini kanıtlamaz."}
			]
			questions = _questions("biletteki isim", "koltuk numarası", "rezervasyonun nasıl yapıldığı", "Bileti arkadaşım aldı, adımı doğru verdiğini söyledi.", "Koltuk numaram 14B olmalı.", "Soyadımda iki harf sık karıştırılıyor.")
			solution = "Kimlikte %s yazıyor, bilette ise %s. %s" % [full_name, ticket_name, "İsimler eşleşiyor." if allowed else "Fotoğraf kimliği doğrulasa da bu bilet başka bir yolcuya ait."]
		2:
			var ticket_destination: String = destination if allowed else DESTINATIONS[(DESTINATIONS.find(destination) + 2) % DESTINATIONS.size()]
			dialogue = "%s'ye geçeceğim. Orada %s yakınında buluşmam var; yanlış iskelede inemem." % [destination, suffix]
			ticket = "Varış iskelesi: %s. Sefer kodu bu geceye ait." % ticket_destination
			clues = [
				{"title": "Aktarma kartı", "body": "Kartta %s yazıyor. Bu duraktan sonra hangi hatta geçileceğini haritadaki renkli çizgiden takip et." % destination},
				{"title": "İskele haritası", "body": "%s hattı %s'den kalkıyor. İki durak arasındaki isim benzerliğine dikkat et." % [destination, DESTINATIONS[(DESTINATIONS.find(destination) + 1) % DESTINATIONS.size()]]},
				{"title": "Buluşma mesajı", "body": "Mesajda yalnızca %s yakınındaki buluşma noktası yazıyor. Biletteki iskele adını kendi başına doğrulamıyor." % suffix}
			]
			questions = _questions("buluşma noktası", "hat rengi", "biletin alındığı yer", "Haritadaki yeşil hattı takip etmem söylendi.", "İskele isimlerini karıştırmış olabilirim.", "Bileti gişeden aldım, acelem vardı.")
			solution = "Yolcu %s dedi; bilet %s iskelesine kesilmiş. %s" % [destination, ticket_destination, "Güzergâh tutarlı." if allowed else "Bilet, anlatılan varış noktasına gitmiyor."]
		3:
			var cargo_claim := "iki çerçeveli baskı"
			var cargo_record := cargo_claim if allowed else "üç kapalı metal kutu"
			dialogue = "%s olarak kırılabilir %s taşıyorum. Hepsini görevliye bildirdim." % [role, cargo_claim]
			ticket = "Yolcu ve küçük el bagajı kayıtlı. Ek yük beyanı: %s." % ("dosyada var" if allowed else "dosyada bulunamadı")
			clues = [
				{"title": "Yük fişi", "body": "Fişte kayıtlı yük: %s. Yolcunun beyanındaki eşya türü ve adetle karşılaştır." % cargo_record},
				{"title": "Kutu mührü", "body": "Mühür numarası 8%s. Aynı numarayı yük fişindeki küçük satırda ara." % str(variant + 21)},
				{"title": "Kırılabilir etiketi", "body": "Etiket doğru takılmış. Eşyanın kırılabilir olması beyanın eksiksiz olduğu anlamına gelmez."}
			]
			questions = _questions("yük fişi", "mühür numarası", "eşya adedi", "Kutuları atölyeden teslim aldım.", "Fişte iki parça yazdığını sanıyordum.", "Mühür numarasını kontrol edebilirsiniz.")
			solution = "Yolcu %s beyan etti; yük fişinde %s kayıtlı. %s" % [cargo_claim, cargo_record, "Eşya ve kayıt eşleşiyor." if allowed else "Beyan edilmeyen metal kutular kayıtta görünüyor."]
		4:
			var appointment := "05.10" if allowed else "02.40"
			dialogue = "%s'de %s ile buluşacağım. Randevum vapur indikten sonra; saati not ettim." % [destination, suffix]
			ticket = "Sefer varış tahmini 04.05. Buluşma saati için ayrı bir not taşınıyor."
			clues = [
				{"title": "Randevu kartı", "body": "Üzerindeki saat %s. Varış tahmini 04.05 ile karşılaştır; kartın tarihini de kontrol et." % appointment},
				{"title": "Cep takvimi", "body": "Bugünün tarihi sayfada işaretli. Bir önceki sayfadaki saat, yolcunun bu geceki randevusu değil."},
				{"title": "Mesaj dökümü", "body": "Karşı tarafın son mesajında yalnızca 'kapıda bekliyorum' yazıyor; saat bilgisi yok."}
			]
			questions = _questions("randevu saati", "varış gecikmesi", "karşı tarafın mesajı", "Saat değişmiş olabilir, kartı güncellemedim.", "Buluşma yerini biliyorum, saati ezberlemiştim.", "Notu dün akşam hazırladım.")
			solution = "Vapur 04.05'te varıyor; randevu kartında %s yazıyor. %s" % [appointment, "Buluşma varıştan sonra." if allowed else "Randevu vapur varmadan önce; yolcunun planı bu seferle yetişmiyor."]
		5:
			var pass_valid := allowed
			var pass_name: String = full_name if pass_valid else FIRST_NAMES[(index + 5) % FIRST_NAMES.size()] + " " + LAST_NAMES[(index + 2) % LAST_NAMES.size()]
			dialogue = "%s vardiyasından çıktım. %s'deki görev noktasına geçmem gerekiyor; kartım çantamda." % [role, destination]
			ticket = "Personel geçiş kartı: %s. Geçerlilik satırı ve fotoğraf ayrıca incelenmeli." % pass_name
			clues = [
				{"title": "Vardiya listesi", "body": "%s için bu geceki görevli adı %s. Karttaki isimle ve yolcunun kimliğiyle eşleştir." % [destination, full_name]},
				{"title": "Yetki kartı", "body": "Kartın son geçerlilik günü ayın %d'i. Bu gece ayın %d'i; tarihleri karşılaştır." % [18 + variant % 8, 17 + variant % 8]},
				{"title": "Fotoğraf", "body": "Kart fotoğrafındaki kişi yolcuya benziyor. Benzerlik, vardiya listesinde adının bulunduğunu tek başına kanıtlamaz."}
			]
			questions = _questions("vardiya listesi", "kartın süresi", "görev yeri", "Beni bu gece listesine sonradan eklediler.", "Kartı geçen ay yeniledim.", "Görev yerim iskele binasının arkası.")
			solution = "Vardiya listesinde %s var; kartta %s yazıyor. %s" % [full_name, pass_name, "Kimlik ve görev kaydı uyuşuyor." if allowed else "Yetki kartındaki isim vardiya listesinde kayıtlı kişiyle aynı değil."]
		6:
			var claimed_code := "K-%03d" % (120 + variant * 7 + index % 10)
			var receipt_code := claimed_code if allowed else "K-%03d" % (121 + variant * 7 + index % 10)
			dialogue = "%s'den %s kodlu emaneti alacağım. Teslim fişim burada; sırada bekleyen yakınım var." % [destination, claimed_code]
			ticket = "Emanet fişi mevcut. İsim ve kodu teslim defteriyle karşılaştır."
			clues = [
				{"title": "Teslim defteri", "body": "Defterde görünen kod %s. Yolcunun söylediği kodla karakter karakter karşılaştır." % receipt_code},
				{"title": "Fiş yırtığı", "body": "Fişin köşesi yırtılmış; yırtık şekli defterdeki nüshayla örtüşüyor. Kodun tamamını doğrulamıyor."},
				{"title": "Emanet etiketi", "body": "%s yazılı etiket kapalı pakette duruyor. Etiketin kime ait olduğunu defter belirliyor." % suffix}
			]
			questions = _questions("teslim kodu", "fişin yırtık köşesi", "paketin etiketi", "Kodun son rakamını aceleyle yanlış söyledim.", "Fişi bana iş yerinde verdiler.", "Paketi görmedim, yalnızca teslim alacağım.")
			solution = "Yolcunun söylediği kod %s; teslim defterinde %s kayıtlı. %s" % [claimed_code, receipt_code, "Emanet fişi eşleşiyor." if allowed else "Kodun son rakamı teslim kaydıyla uyuşmuyor."]
		7:
			var onward := "05.20" if allowed else "03.35"
			dialogue = "%s'ye varınca %s durağından devam edeceğim. Aktarma biletim cebimde." % [destination, suffix]
			ticket = "Vapurun tahmini varışı 04.05. Aktarma saati bilette ayrı basılmış."
			clues = [
				{"title": "Aktarma bileti", "body": "Sonraki aracın kalkış saati %s. Vapurun 04.05 varışını ve iskeleler arası yürüyüş süresini hesaba kat." % onward},
				{"title": "Durak krokisi", "body": "İki durak arası yürüyüş en az 18 dakika. Vapur rıhtıma yanaşmadan aktarmaya geçilemez."},
				{"title": "İskele saati", "body": "Saat 03.42. Bu, sonraki aracın hareket saatinden önce; varış tahmini ise daha geç olabilir."}
			]
			questions = _questions("aktarma saati", "yürüme süresi", "vapurun varış tahmini", "Gecikme payı bıraktım, bağlantı saati daha geç olmalı.", "Krokideki kestirme yolu kullanacağım.", "Saatler tarifede yazıyor, ben hesaplamadım.")
			solution = "Vapur 04.05'te yanaşıyor ve aktarma iskelesine yürümek 18 dakika sürüyor; sonraki araç %s'te. %s" % [onward, "Yolcunun aktarmaya yetişmesi mümkün." if allowed else "Aktarma vapur yanaşmadan kalkıyor; yürüyüş süresi de hesaba katılmamış."]
		8:
			var guest_name: String = full_name if allowed else FIRST_NAMES[(index + 2) % FIRST_NAMES.size()] + " " + LAST_NAMES[(index + 13) % LAST_NAMES.size()]
			var event_date: String = "bu akşam 19.00" if allowed else "dün akşam 19.00"
			dialogue = "%s'deki %s açılışına davetliyim. Listede adımın olduğunu söylediler; daveti çantamda taşıyorum." % [destination, suffix]
			ticket = "Etkinlik kartı: %s. Tarih ve davetli listesiyle birlikte doğrulanmalı." % guest_name
			clues = [
				{"title": "Davetli listesi", "body": "Listede %s adına bir kayıt var. Kartta soyadın ilk harfi silik; tam isim eşleşmesini incele." % full_name},
				{"title": "Etkinlik tarihi", "body": "Davet kartında %s yazıyor. Bu geceki seferin tarihiyle karşılaştır." % event_date},
				{"title": "Salon planı", "body": "%s salonu kıyı atölyesinin yanında. Mekân bilgisi doğru olabilir; tarih ve isimden ayrı değerlendir." % suffix}
			]
			questions = _questions("davetli listesi", "etkinlik tarihi", "salonun yeri", "Davetiyeyi e-posta ile göndermişlerdi.", "Saat değişikliğini duymadım.", "İsmim listede kısaltılmış olabilir.")
			solution = "Davetli listesi %s adına kayıtlı; kartta %s yazıyor. Açılış tarihi %s. %s" % [full_name, guest_name, event_date, "İsim ve tarih eşleşiyor." if allowed else "Kart başka bir isme düzenlenmiş ve etkinlik tarihi geçmiş."]
		9:
			var date_text := "bu gece" if allowed else "dün gece"
			dialogue = "%s seferiyle %s'ye geçeceğim. Biletimi %s aldım; saate yetişmek için koştum." % ["03.30", destination, date_text]
			ticket = "Bilette sefer kodu okunuyor; tarih damgası katlanmış bölümün altında."
			clues = [
				{"title": "Tarih damgası", "body": "Damgada %s yazıyor. Peron panosundaki tarihle ve biletin saatinden bağımsız olarak karşılaştır." % ("bugünün tarihi" if allowed else "önceki günün tarihi")},
				{"title": "Sefer kodu", "body": "Kod 03.30 seferine ait; aynı kod dün de kullanılmıştı. Kod tek başına biletin bu geceye ait olduğunu göstermez."},
				{"title": "Katlanmış kenar", "body": "Kâğıt yıpranmış ve köşesi kıvrılmış. Fiziksel yıpranma tarihin geçerli olup olmadığını kanıtlamıyor."}
			]
			questions = _questions("tarih damgası", "sefer kodu", "biletin alındığı saat", "Aynı sefer kodunun her gece kullanıldığını bilmiyordum.", "Bileti gişeden aldığım saati hatırlıyorum.", "Köşesi cebimde katlanmış.")
			solution = "Sefer kodu her gece tekrarlanıyor; biletin tarih damgası %s. %s" % ["bu gece" if allowed else "dün gece", "Bilet bu gece için geçerli." if allowed else "Dünkü tarih damgası bileti bu sefer için geçersiz kılıyor."]
	var fragment := ""
	var difficulty := int(index / 20) + 1
	if difficulty >= 3:
		clues.insert(1, {"title": "YAN KAYIT", "body": RED_HERRINGS[pattern]})
	if difficulty >= 5:
		clues.insert(2, {"title": "ESKİ NÖBET NOTU", "body": "Önceki vardiyadan kalan not: 'Bir ayrıntı tek başına hiçbir şeyi kanıtlamaz; aynı bilgiyi ikinci bir kayıtta ara.'"})
	if index % 10 == 9:
		fragment = THREAD_CLUES[int(index / 10)]
		clues.append({"title": "NÖBET DEFTERİNDEN KOPMUŞ SAYFA", "body": fragment})
	return {
		"dialogue": dialogue,
		"ticket": ticket,
		"clues": clues,
		"questions": questions,
		"key_clues": [-1, 0],
		"case_question": "Belgeler ile yolcunun beyanı bu sefer için tutarlı mı?",
		"case_note": solution,
		"fragment": fragment
	}


static func _questions(topic_a: String, topic_b: String, topic_c: String, answer_a: String, answer_b: String, answer_c: String) -> Array[Dictionary]:
	return [
		{"q": "%s hakkında sor" % topic_a.capitalize(), "a": answer_a},
		{"q": "%s hakkında sor" % topic_b.capitalize(), "a": answer_b},
		{"q": "%s hakkında sor" % topic_c.capitalize(), "a": answer_c}
	]
