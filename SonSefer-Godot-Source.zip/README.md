# Son Sefer: Gece Vardiyası

Godot 4 ile hazırlanmış, görselleri ve arayüzü kodla çizilen 2D oyun prototipi. Beş başlangıç hikâyesi ve on farklı çapraz kontrol türüne dayanan 95 ek yolcu dosyasıyla toplam 100 karar turu vardır. Zorluk beş kademede artar; son kademelerde ek yan kayıtlar gelir.

## Çalıştırma

1. Godot 4'ü indirip kurun.
2. Godot Project Manager'dan **Import** seçin.
3. Bu klasördeki `project.godot` dosyasını seçin.
4. Proje açılınca **F5** tuşuyla veya üstteki **Run Project** düğmesiyle oyunu başlatın.

Oyunda ana menü, ayarlar, büyük yazı ve yüksek kontrast seçenekleri, soru başına tek ek soru hakkı, otomatik ilerleme kaydı, karar sonrası iskele animasyonu, 10 bölümlük hikâye, geri dönen yolcular, iskele güveni, vardiya defteri ve yedi farklı final bulunur. Her bölüm içinde ilk dokuz dosyanın sırası yeni vardiyada karıştırılır; gizli nöbet sayfası son dosyada kalır. Kanıt panosunda bilet ve ipuçlarını eşleştirerek çıkarım yapabilirsin. Rahat modda süre yoktur; Normal 90 saniye, Zor 45 saniye verir. Yerel başarımlar ve yeniden oynanabilir vaka sırası kaydedilir. Arka planın gece ışığı, sis, yağmur, su hareketi ve düşük seviyeli iskele ambiyansı kodla üretilir. Oyun Godot 4 ile, harici sanat/ses varlığı olmadan çalışır.

## Steam başarımları

Windows x64 için GodotSteam 4.24 GDExtension ve `steam_bridge.gd` projeye eklendi. Steamworks aktarım CSV'leri, ikonlar ve adım adım test yönergesi `steamworks/` klasöründe. Debug yapısındaki Başarımlar ekranında yerel başarımları ücretsiz açıp sıfırlayabilirsin. Gerçek hesaba başarı göndermek için oyunun Steamworks App ID'si, Steamworks'te yayımlanmış başarı tanımları ve erişim yetkili Steam hesabı gerekir. App ID gelmeden Steam tarafına test unlock'ı gönderilemez; yerel oyun içi başarımlar çalışmaya devam eder.

## Windows dışa aktarma

Godot içindeki **Editor > Manage Export Templates** bölümünden eşleşen export template'lerini yükleyin. Sonra **Project > Export** ile Windows Desktop preset'i ekleyip `.exe` çıktısı alın. Steam'e yüklemek için ayrıca Steamworks partner hesabı ve SteamPipe üzerinden build yükleme adımları gerekir.
