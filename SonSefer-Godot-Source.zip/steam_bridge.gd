extends Node

## Optional GodotSteam bridge. The game still runs without the extension;
## locally saved achievements remain available in that case.

var steam_api: Object
var connected := false
var status_message := "GodotSteam eklentisi yüklenmedi."


func _ready() -> void:
	if not Engine.has_singleton("Steam"):
		status_message = "GodotSteam GDExtension bulunamadı."
		return
	steam_api = Engine.get_singleton("Steam")
	if steam_api.has_method("steamInitEx"):
		var result: Variant = steam_api.call("steamInitEx")
		if result is Dictionary:
			connected = int(result.get("status", -1)) == 0
			status_message = String(result.get("verbal", "Steam API başlatıldı."))
	elif steam_api.has_method("steamInit"):
		var result: Variant = steam_api.call("steamInit")
		connected = bool(result)
		status_message = "Steam API başlatıldı." if connected else "Steam başlatılamadı."
	if not connected:
		steam_api = null
	print("Son Sefer Steam bridge: ", status_message)


func _process(_delta: float) -> void:
	if connected and steam_api.has_method("run_callbacks"):
		steam_api.call("run_callbacks")


func unlock(achievement_id: String) -> bool:
	if not connected or steam_api == null:
		return false
	var api_name := achievement_id.to_upper()
	if steam_api.has_method("getAchievement"):
		var current: Variant = steam_api.call("getAchievement", api_name)
		if current is Dictionary and bool(current.get("achieved", false)):
			return true
	if not steam_api.has_method("setAchievement"):
		return false
	var result: Variant = steam_api.call("setAchievement", api_name)
	if result is bool and not result:
		return false
	if steam_api.has_method("storeStats"):
		return bool(steam_api.call("storeStats"))
	return false


func clear(achievement_id: String) -> bool:
	if not connected or steam_api == null or not steam_api.has_method("clearAchievement"):
		return false
	var cleared: bool = bool(steam_api.call("clearAchievement", achievement_id.to_upper()))
	if not cleared:
		return false
	return bool(steam_api.call("storeStats")) if steam_api.has_method("storeStats") else false
