# Son Sefer — Steam achievement test setup

The GodotSteam 4.24 GDExtension (Steamworks SDK 1.65) is included for Windows x86_64. It matches Godot 4.7.2. The addon is MIT licensed; see `../addons/godotsteam/license.md`. Without any Steamworks account, use the debug build's **Achievements** screen to unlock all seven local achievements and reset them for free. This checks the in-game achievement UI and save behavior, but does not modify a Steam profile.

## Steamworks account setup

Steam achievements are attached to a Steamworks application. The game cannot send real Steam unlocks until its owner has an App ID and has configured achievements in that app.

1. In Steamworks, open this game's **Stats & Achievements** settings and configure **English** and **Turkish** as achievement languages.
2. Open **Bulk Import/Export**. Upload `son-sefer-achievements-definitions.csv`, `son-sefer-achievements-localization.csv`, and every `icons/*_ACHIEVED.png` file together. Steamworks can generate grayscale locked icons from the achieved icons.
3. Review the pending changes and save them. Publish the Steamworks changes so the API names are live. The API names must remain exactly as listed in the CSV and in `main.gd`.
4. Put the app's numeric Steam App ID in a file named `steam_appid.txt` beside the game executable while running locally. `steam_appid.txt.example` is a template; replace its text with the real numeric ID. Do not ship this file in the Steam depot: Steam supplies the App ID when launching the app through the client.
5. Use a Steam account that has access to the app, keep the Steam client running, and launch the game. Open **Achievements**; the debug build shows a button to unlock `FIRST_DUTY` and another to clear that test achievement. The Steam overlay can be unreliable when launched from the Godot editor, so check the profile/achievement page too.

The normal game unlocks each API name at its gameplay milestone and calls `StoreStats` immediately. Locally saved unlocks are also sent to Steam after a successful Steam initialization.

## What still needs the app owner

This folder is ready to import, but it cannot create a Steamworks app, grant account access, publish the achievement definitions, or supply the real App ID. Those actions require the game's Steamworks Partner account. Until those are completed, the game's own local achievement list works, while Steam reports an unavailable connection.

## Testing / resetting

The debug-only `FIRST_DUTY` test control can unlock and clear the sample achievement after Steam is connected. Valve also documents the Steam client console commands `achievement_clear <appid> <achievement_name>` and `reset_all_stats <appid>` for development. Do not use the full reset command on a production account unless you intend to erase that app's stats and achievements.
